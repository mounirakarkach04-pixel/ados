# ADOS Governance Lite v0.6 — abschließendes Forschungs-Testpaket

## Sofort nutzbar
Öffne `ADOS_Governance_Lite_v0_6_OFFLINE_EINZELDATEI.html` im Browser. Bestätige fiktive Datennutzung. Führe A–F aus, erfasse im optionalen A7SEM-Teil pro Stufe einen synthetischen Evidenzstatus und eine Evidence-ID. Gib in A7SEM Reverse jeweils Quelle, Claim-ID und explizite Zuordnungsbestätigung an. Im Prüfergebnis den **Finite Loop** oder einen einzigen Re-Entry-Tick aufrufen. Ohne bestätigte Zuordnung bleibt UNKNOWN/DELAY.

## Mathematische Matrix
Die Datei `ADOS_A7SEM_PIGA_GOVERNANCE_MATRIX_v0_6.xlsx` enthält 9 Blätter: START, DASHBOARD, FAELLE, A7SEM, FINITE, CHECKPOINT, TESTS, REGELN, QUELLEN. Formeln bestimmen Demo-Gates, 70 A7SEM/Reverse-Prüfzellen, sieben deterministische Iterationen pro Fall, Checkpoint-Grenzen und 10 testbare erwartete Gate-Paare. Alle Formeln bleiben sichtbar und bearbeitbar. Kein VBA, kein Excel-Makro und kein unendlicher Loop.

## Wiederholbare CLI-Prüfung
Node.js 22+ ohne npm-Abhängigkeiten. Im Quellordner:

```
node tests/test-engine.cjs
node tests/test-v02.cjs
node tests/test-bridge.cjs
node tests/test-integrity.cjs
node tests/test-core-identity.cjs
node tests/test-local-bridge-v05.mjs
node tests/test-governed-loop.cjs
```

Alle 115 Testgruppen wurden am 23.10.2026 lokal bestanden (90 bisherige + 25 neue). Browser-Bridge-E2E bleibt wegen isolierter localhost-Sperre unbestätigt.

## Finite / Infinite (begrenzt)
`finite` traversiert höchstens sieben A7SEM-Perspektiven und prüft per Stage ein Paar aus expliziter Evidence-ID + Reverse-Bezug. Bei Widerspruch, Evidenzlücke, Duplikat oder klinischer Anfrage STOP. `continuousTick` ist ein einzelner explizit ausgelöster Tick mit Human-Review, neuer Epoche, TTL, Widerruf und 64-Tick-Quota. **Es gibt keinen unendlichen Ausführungsprozess; ein solcher wäre bei fehlender Autorität unzulässig.**

## PIGA Infrastruktur
Das vorhandene private GitHub-Repository `mounirakarkach04-pixel/piga-pocket-enterprise` und PIGA K2.1.1 External Dossier sind Referenzen. Ein sicher getrennter GitHub-Review-Branch darf erstellt werden; keine Änderungen an Main, Edge Functions, Secrets, Runner oder fünf Engines für die Demo.

## Sicherheitsgrenze
Die Software ist keine klinische App. Keine realen Patientendaten eingeben. Sämtliche kanonische Inferenz- und Handlungszulassung bleiben BLOCK, auch wenn die lokale Prüfung formal vollständig ist.
