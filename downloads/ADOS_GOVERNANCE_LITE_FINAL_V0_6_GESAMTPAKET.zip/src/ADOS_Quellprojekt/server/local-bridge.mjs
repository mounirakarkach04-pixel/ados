/**
 * ADOS Governance Lite v0.5 — LOCAL, NONCANONICAL DENIAL BRIDGE.
 * No clinical action. No canonical PIGA key. No patient data. No network egress.
 * Durable demonstration of single-use nonces and revocation across restarts.
 * This bridge NEVER grants ALLOW, including when the audit ledger is unavailable.
 */
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export const SCHEMA='ados-local-bridge-receipt/0.5';
export const REQUEST='ados-governance-admission-request/0.3';
export const PORT=8767;
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
const allowable=new Set(['index.html','styles.css','app.js','engine.js','kernel-bridge.js','integrity.js','core-identity.js','manifest.webmanifest','icon.svg','sw.js']);
const closed=(code,reason)=>({status:'BLOCK',code,reason,authoritative:false});
const safeId=x=>typeof x==='string'&&/^[a-zA-Z0-9:_-]{8,128}$/.test(x);
const safeNonce=x=>typeof x==='string'&&/^[a-f0-9]{32}$/.test(x);
function validate(v,now){
 if(!v||typeof v!=='object'||Array.isArray(v))return 'INVALID_REQUEST';
 const keys=new Set(['schema','capability','nonce','requestId','createdAt','expiresAt','scope','caseRef','claimType','nextAction','safety','payload','evidenceRefCount']);
 if(Object.keys(v).some(k=>!keys.has(k)))return 'UNEXPECTED_FIELDS';
 if(v.schema!==REQUEST||v.capability!=='ADOS_EVIDENCE_GOVERNANCE')return 'UNRECOGNIZED_SCHEMA';
 if(v.scope!=='DEMO_DOCUMENTATION_ONLY'||v.caseRef!=='FIKTIV'||v.payload!=='NOT_INCLUDED'||v.evidenceRefCount!==0)return 'DATA_SCOPE_BLOCK';
 if(!safeNonce(v.nonce)||v.requestId!==`ADOS-${v.nonce}`||!safeId(v.requestId))return 'NONCE_OR_ID_INVALID';
 if(!Number.isSafeInteger(v.createdAt)||!Number.isSafeInteger(v.expiresAt)||v.expiresAt<=v.createdAt||v.expiresAt-v.createdAt>300000)return 'TIME_INVALID';
 if(v.createdAt>now+10000||v.createdAt<now-120000)return 'CLOCK_SKEW';
 if(v.expiresAt<=now)return 'EXPIRED';
 if(!['observation','working'].includes(v.claimType)||!['document','clarify'].includes(v.nextAction))return 'CLINICAL_SCOPE_BLOCKED';
 if(v.safety!=='no')return 'SAFETY_NOT_CLEARED';
 return null;
}

/** Append-only, fsync'ed, demo-only ID ledger. No case content is ever stored. */
export class LocalLedger {
 constructor(folder){
  if(typeof folder!=='string'||!path.isAbsolute(folder))throw new Error('STATE_PATH_REQUIRED');
  this.folder=folder;
  fs.mkdirSync(folder,{recursive:true,mode:0o700});
  if(!fs.statSync(folder).isDirectory()||fs.lstatSync(folder).isSymbolicLink())throw new Error('STATE_DIRECTORY_INVALID');
  this.lock=path.join(folder,'single-process.lock');
  try{this.lockFd=fs.openSync(this.lock,'wx',0o600);}catch{throw new Error('STATE_ALREADY_LOCKED_FAIL_CLOSED')}
  this.log=path.join(folder,'nonce-ledger.jsonl');
  this.used=new Set();this.revoked=new Set();
  try{
   if(fs.existsSync(this.log)&&fs.lstatSync(this.log).isSymbolicLink())throw new Error('STATE_LEDGER_SYMLINK');
   const lines=fs.existsSync(this.log)?fs.readFileSync(this.log,'utf8'):'';
   for(const line of lines.split('\n')){
    if(!line)continue;
    let v;try{v=JSON.parse(line)}catch{throw new Error('STATE_LEDGER_CORRUPTED')}
    if(v.kind==='use'&&safeNonce(v.nonce)&&v.id===`ADOS-${v.nonce}`)this.used.add(v.nonce);
    else if(v.kind==='revoke'&&safeId(v.id))this.revoked.add(v.id);
    else throw new Error('STATE_LEDGER_ENTRY_INVALID');
   }
   this.fd=fs.openSync(this.log,'a',0o600);
   fs.chmodSync(this.log,0o600);
  }catch(e){this.close();throw e}
 }
 record(kind,item){
  if(!this.fd)throw new Error('STATE_STORE_NOT_READY');
  if(kind==='use'&&(!safeNonce(item.nonce)||item.id!==`ADOS-${item.nonce}`))throw new Error('INVALID_NONCE');
  if(kind==='revoke'&&!safeId(item.id))throw new Error('INVALID_ID');
  const line=JSON.stringify({kind,...item})+'\n';
  const buf=Buffer.from(line);
  if(fs.writeSync(this.fd,buf)!==buf.length)throw new Error('DURABLE_WRITE_INCOMPLETE');
  fs.fsyncSync(this.fd);
  if(kind==='use')this.used.add(item.nonce);
  else this.revoked.add(item.id);
 }
 close(){
  if(this.fd!==undefined){try{fs.closeSync(this.fd)}catch{};this.fd=undefined}
  if(this.lockFd!==undefined){try{fs.closeSync(this.lockFd)}catch{};this.lockFd=undefined;try{fs.unlinkSync(this.lock)}catch{}}
 }
}
export function createLocalService({clock=()=>Date.now(),stateFolder=path.join(ROOT,'.ados-demo-state')}={}){
 const ledger=new LocalLedger(stateFolder);
 const keys=crypto.generateKeyPairSync('ed25519');
 const pub=keys.publicKey.export({type:'spki',format:'der'}).toString('base64');
 let closedService=false;
 function issue(body){
  const signedPayload=JSON.stringify(body);
  return {signedPayload,signature:crypto.sign(null,Buffer.from(signedPayload),keys.privateKey).toString('base64'),publicKeySpki:pub,algorithm:'Ed25519',trustedPigaKey:false};
 }
 function admit(req){
  const now=clock();let reason=validate(req,now)||'CANONICAL_KERNEL_NOT_CONNECTED';
  if(reason==='CANONICAL_KERNEL_NOT_CONNECTED'){
   if(closedService)reason='STATE_UNAVAILABLE';
   else if(ledger.revoked.has(req.requestId))reason='REVOKED';
   else if(ledger.used.has(req.nonce))reason='REPLAY';
   else {try{ledger.record('use',{nonce:req.nonce,id:req.requestId})}catch{reason='STATE_PERSISTENCE_FAILED'}}
  }
  return issue({schema:SCHEMA,kind:'LOCAL_TEST_DENIAL',status:'BLOCK',authoritative:false,gate1:'UNKNOWN',gate2:'BLOCK',reason,requestId:safeId(req?.requestId)?req.requestId:'INVALID',nonce:safeNonce(req?.nonce)?req.nonce:'INVALID',issuedAt:now,expiresAt:now+60000,policyVersion:'LOCAL-TEST-NONCANONICAL-0.5',engineCount:5,additionalEngineCreated:false,casePayloadIncluded:false,persistentReplayProtection:true});
 }
 function revoke(id){if(!safeId(id)||closedService)return false;try{ledger.record('revoke',{id});return true}catch{return false}}
 return {admit,revoke,verifyReceipt:x=>{try{return crypto.verify(null,Buffer.from(x.signedPayload),keys.publicKey,Buffer.from(x.signature,'base64'))}catch{return false}},status:()=>({mode:'LOCAL_TEST_ONLY',kernelStatus:'BLOCK',canonicalAdmission:false,engineCount:5,additionalEngineCreated:false,publicKeySpki:pub,publicKeyTrusted:false,persistentReplayProtection:!closedService,patientDataAllowed:false}),stats:()=>({usedNonces:ledger.used.size,revocations:ledger.revoked.size}),close(){if(!closedService){ledger.close();closedService=true}}};
}
export function createServer({service,port=PORT}={}){
 const svc=service||createLocalService();
 const origin=`http://127.0.0.1:${port}`;
 const srv=http.createServer(async(req,res)=>{
  const headers={'cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','cross-origin-resource-policy':'same-origin','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"};
  const send=(code,body)=>{res.writeHead(code,{'content-type':'application/json; charset=utf-8',...headers});res.end(JSON.stringify(body))};
  // Reject DNS rebinding hostnames and loopback aliases; exact origin is part of the local demo boundary.
  if(req.headers.host!==`127.0.0.1:${port}`)return send(403,closed('HOST_BLOCK','Loopback host mismatch'));
  const raw=(req.url||'/').split('?')[0];
  if(req.method==='GET'&&raw==='/api/ados/bridge/status')return send(200,svc.status());
  if(req.method==='POST'&&raw==='/api/ados/bridge/admission'){
   if(req.headers.origin!==origin||req.headers['sec-fetch-site']==='cross-site')return send(403,closed('ORIGIN_NOT_ALLOWED','Local same-origin only'));
   if(req.headers['x-ados-local-demo']!=='1'||!/^application\/json(?:;|$)/i.test(req.headers['content-type']||''))return send(415,closed('HEADER_REQUIRED','JSON and explicit demo marker required'));
   let body='';
   try{for await(const c of req){body+=c;if(Buffer.byteLength(body,'utf8')>4096)return send(413,closed('OVERSIZE','Metadata only'))}}catch{return send(400,closed('BODY_ERROR','Invalid body'))}
   let parsed;try{parsed=JSON.parse(body)}catch{return send(400,closed('INVALID_JSON','Malformed JSON'))}
   return send(200,svc.admit(parsed));
  }
  if(raw.startsWith('/api/'))return send(404,closed('NO_ENDPOINT','Not a production admission API'));
  if(!['GET','HEAD'].includes(req.method))return send(405,closed('METHOD_NOT_ALLOWED','Unsupported method'));
  let name;try{name=raw==='/'?'index.html':decodeURIComponent(raw.slice(1))}catch{return send(400,closed('BAD_PATH','Invalid URL'))}
  if(!allowable.has(name))return send(404,closed('NOT_FOUND','Not exposed'));
  try{
   const bytes=await fsp.readFile(path.join(ROOT,name));
   res.writeHead(200,{'content-type':mime[path.extname(name)]||'application/octet-stream',...headers});
   if(req.method==='HEAD')res.end();else res.end(bytes);
  }catch{return send(404,closed('NOT_FOUND','Missing asset'))}
 });
 return srv;
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===path.resolve(process.argv[1])){
 const port=Number(process.env.ADOS_DEMO_PORT||PORT);
 if(port!==PORT){console.error('BLOCK: only local port 8767 supported');process.exit(2)}
 let svc;
 try{svc=createLocalService()}catch(err){console.error(JSON.stringify({status:'BLOCK',reason:String(err)}));process.exit(2)}
 const server=createServer({service:svc,port});
 server.once('error',err=>{svc.close();console.error('BLOCK local server: '+err);process.exit(2)});
 server.listen(port,'127.0.0.1',()=>console.log(JSON.stringify({service:'ADOS local signed DENIAL bridge',url:`http://127.0.0.1:${port}`,kernel:'BLOCK',persistentDemoNonces:true,patientData:false})));
 for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.close(()=>{svc.close();process.exit(0)}));
}
