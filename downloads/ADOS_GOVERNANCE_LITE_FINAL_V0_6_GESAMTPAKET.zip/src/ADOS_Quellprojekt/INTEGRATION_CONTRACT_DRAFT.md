# ADOS v0.5 — verbindliche Quellgrenzen und zukünftiger Adaptervertrag

## Aus überprüftem Originalmaterial
- Drive: PIGA K2.1.1 External Product Dossier v1.3.2, 23.07.2026, Google Doc `1ah0n21IZiSe6MgL_GMI-N552NW6fq0g7oLscldRBJ_c`, archivierter Core v0.7, SHA-256 `a84001ad8cf3e5aef9123b33e641f6012b4ffc3b67814630121ebbd5bdc63605`, Scope-Hash `e3206c695a0c35b0e796a87bba5484fbb66267b83e16aa586f99cc50091e5c9f`; Freigabe nur controlled evaluation/non-production adaptation, production not released.
- GitHub: privates Repository `mounirakarkach04-pixel/piga-pocket-enterprise`, geprüfter main-tree `4aa3d93f810717ac4291d7eecf55d2aa0173deef`; Gate1/Gate2-Statuswerte `ALLOW/DELAY/BLOCK/UNKNOWN/EXPIRED` aus generierten Typen. Der Factory Runner verlangt `PIGA_API_ORIGIN`, `PIGA_FACTORY_WATCHDOG_SECRET`; niemals an den Client geben. `supabase/functions/piga-action-plane-admission-v1/index.ts` unterstützt externe Aktionen email/deployment/payment/publication/account_change – **nicht** ADOS.

## Nicht durch Originalmaterial belegt
Keine autorisierte produktive ADOS-Kernel-Schnittstelle, keine klinisch validierte Entscheidungslogik, kein bestätigter signierter Scope-Pass für diesen Zweck, kein Produktions-Widerrufsendpunkt. Diese Lücken dürfen nicht durch erfundene Bescheide ergänzt werden.

## Vorläufiger Testvertrag
Anfrage: `ados-governance-admission-request/0.3`, reiner fiktiver Marker ohne Falltext, 128-Bit-Nonce, `createdAt/expiresAt`, Observation/Working Hypothesis, Document/Clarify.
Antwort: `ados-local-bridge-receipt/0.5`, nur `BLOCK`, `authoritative=false`, Gate1 `UNKNOWN`, Gate2 `BLOCK`, Ed25519-signierte Testdaten, höchstens 60 s gültig, lokaler temporärer Schlüssel. Keine Freigabe selbst bei gültiger Signatur.

## Offene Bausteine vor Produktiveinsatz
Kanonisches Schema + signierter Zweck/Scope, unabhängiger Trust Root, vorab validierter Inference-/Action-Policy-Kernel, serverseitige Identity/Permissions, durable distributed single-use nonce/revocation and expiry, Evidence-/A7SEM-Reverse-Readback, Fachevaluation und Regulierung. Bis dahin `BLOCK`.
