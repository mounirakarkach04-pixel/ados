# PIGA K2.1.1 Core-Provenienz für ADOS v0.5

## Aufgefundene Quellen (live, 23.10.2026)

- Google Drive: **PIGA K2.1.1 External Product Dossier v1.3.2**, https://docs.google.com/document/d/1ah0n21IZiSe6MgL_GMI-N552NW6fq0g7oLscldRBJ_c/edit?usp=drivesdk
- Google Drive: **PIGA Authority Source Resolution & Conflict Specification v1.0**, https://docs.google.com/document/d/1B1ntdgEcZ-soJCwt_2oqWyOnmE4jhaKXbg_ZpMzTtVU/edit?usp=drivesdk
- Privates Pocket-Enterprise-Repository: `lib/api-zod/src/generated/types/factoryJobInferenceAdmission.ts` und `factoryJobActionAdmission.ts`, dieselbe Fünfermenge ALLOW, DELAY, BLOCK, UNKNOWN, EXPIRED.
- Privates Repository: `supabase/functions/piga-action-plane-admission-v1/index.ts`, Action-Plane-Klassen aktuell email/deployment/payment/publication/account_change; **keine** nachgewiesene ADOS-Patientendiagnose-Fähigkeit.

## Dokumentierte Identitätswerte

- Akzeptiertes Core-Paket: `PIGA_K2.1.1_RC_20260723_INTEGRATED_PROGRAM_CONTROL_v0.7.zip`
- Exact bundle SHA-256: `a84001ad8cf3e5aef9123b33e641f6012b4ffc3b67814630121ebbd5bdc63605`
- Frozen scope SHA-256: `e3206c695a0c35b0e796a87bba5484fbb66267b83e16aa586f99cc50091e5c9f`
- Core: K2.1.1 RC v0.7; externer Review **ready**, produktive Anwendung **DELAY**, unabhängige Sicherheitsprüfung **PENDING**.

## Technische Implementierung

Ein Nutzer kann in der Browser-Testoberfläche freiwillig sein lokal vorhandenes ZIP auswählen. Browser-WebCrypto berechnet SHA-256 und vergleicht mit dem exakten Byte-Hash. Das gesamte ZIP bleibt lokal und wird **nicht** an die Browser-Bridge, einen Cloud-Dienst oder einen Server übertragen. Auf nicht unterstützten Browsern gilt UNKNOWN; die App behauptet keine Prüfung.

Unabhängig von einem Match bleibt die kanonische Autorität `BLOCK`, weil Bindung der Root of Authority, Signatur/Epoch, aktuelle Widerrufslage, Version des konkreten zulässigen Scopes, menschliche Freigabe und produktive Adapter **nicht** anhand der bloßen Dateiidentität bewiesen werden können. Gleicher Hash bedeutet **nicht** gleiches Recht zur Verwendung. Die gegebene PDF/Doc-Spezifikation benennt dieses Problem ausdrücklich.

## Fehlende Voraussetzung

Das genannte Original-*.zip konnte mit der Suche im zugänglichen Google Drive bzw. lokalen Projektordner nicht als konkrete Datei verifiziert werden. Es wurde deshalb weder ein kanonischer Resolver importiert noch eine echte PIGA-Live-Entscheidung ausgeführt. Die Demo-Regeln wurden nicht als Ersatz ausgegeben. Kein Deployment, keine Änderung an den fünf bestehenden Engines.
