# ADOS v0.5 · Autoritäts- und Sicherheitsgrenze

- `ALLOW/DELAY/BLOCK/UNKNOWN/EXPIRED`: nur der Statuswortschatz wird aus vorhandenen Pocket-Enterprise-Typen übernommen; die lokalen Gate-Regeln bleiben nachweislich **DEMO**.
- Der dokumentierte PIGA K2.1.1 RC Core v0.7 ist laut Dossier für kontrollierte externe Evaluation und nichtproduktive Adaption zulässig, **nicht für produktive Gate-Autorität**.
- SHA-256-Match dient allein der Identitätsprüfung eines ausgewählten lokalen ZIPs. Kein gleichzeitiger Scope-, Unterschrifts-, Widerrufs-, Trust-Root- oder Laufzeitnachweis.
- Es wird **kein** Core-Bundle hochgeladen, kein Runner aktiviert, kein Secret kopiert, kein neuer Worker/Engine erstellt und keine reale medizinische Aussage zugelassen.
- Ed25519 dient nur dem Nachweis, dass lokale Testbescheide vom laufenden Testdienst signiert wurden. Der Schlüssel ist flüchtig und nicht kanonisch oder vorab vertrauensverankert. Er signiert **ausschließlich BLOCK**.
- Dauerhafte Nonces/Widerrufe liegen lokal in einer append-only-Datei mit `fsync`, mit exklusiver Prozess-Lockdatei. Geeignet für kontrollierte Single-Process-Testläufe, **nicht** für Multi-Worker-Konkurrenz, HSM-Trust oder Produktionswiederanlauf. Ein Fehler in der Ledger-Datei führt zum Dienst-Startabbruch. Keine Testfälle im Ledger.
- Ein echter medizinischer/gesundheitsbezogener Betrieb würde Zweckbestimmung, DSGVO/MDR, Bedrohungsanalyse, gesicherte Speicherung, externen Fachevaluationsprozess und erforderliche regulatorische Freigaben voraussetzen.
- Version v0.5 hat 90 automatisch ausgeführte Testgruppen. Browser-lokaler HTTP-End-to-End-Zugriff wurde durch Sandboxrichtlinien nicht bestätigt.
