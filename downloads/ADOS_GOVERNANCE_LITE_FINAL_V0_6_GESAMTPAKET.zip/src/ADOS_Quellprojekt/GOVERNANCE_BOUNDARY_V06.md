# ADOS Governance Lite v0.6 — Autoritätsgrenze

**Status:** RESEARCH ONLY. Keine produktive, klinische oder kanonische ADOS-Gate-Autorität.

1. Beibehaltene fünf bestehende Pocket-Enterprise-Engines; keine sechste Engine erstellt.
2. v0.5-Demo-Gate-Logik unverändert. Neue A7SEM/Reverse-Checks liefern ausschließlich `REVIEW_READY_NONAUTHORITATIVE` oder restriktivere Zustände.
3. Jede unverifizierte, widerrufene, widersprüchliche oder fehlende Referenz stoppt einen endlichen Loop.
4. Ein kontinuierlicher Loop besteht ausschließlich aus voneinander getrennten endlichen, menschlich geprüften Ticks. Ohne neue Evidence-Epoche kein Re-Entry. Quota 64; Expiry und Revocation sind bindend. Es gibt keinen Hintergrunddienst.
5. K2.1.1 RC v0.7: DOI oder Dokumentenlage erzeugen keine delegierte Root of Authority. Das Dossier autorisiert nur kontrollierte Evaluation/nichtproduktive Anpassung.
6. `ALLOW` im alten Gate-1/2-Demo-Befund bezieht sich ausschließlich auf FIKTIVE nichtklinische Dokumentation. `canonicalAuthority.status` bleibt BLOCK.
7. Die Offline-Einzeldatei enthält alle Skripte; `connect-src none`, keine Serverkommunikation oder Datenspeicherung. Ihre JSON-Exporte sind nicht verschlüsselt.
8. Signierte Testbescheide des bisherigen Local-Bridges sind nicht produktiv vertrauenswürdig; keine externen Effekte.
9. Kein EHR, keine personenbezogenen Gesundheitsdaten, keine Diagnosen, keine Therapie und keine CE-Konformität.
