/* ADOS v0.6 — deterministic A7SEM/Reverse research loop, no clinical/admission authority.
   All loop operations are bounded, finite, offline. 'Continuous' is a checkpoint protocol,
   never a self-running agent. Canonical PIGA authority is always BLOCK in this module. */
(function(root,factory){ if(typeof module==='object'&&module.exports)module.exports=factory(require('./engine.js'));
else root.ADOSGovernedLoop=factory(root.ADOSEngine); })(typeof globalThis!=='undefined'?globalThis:this,function(E){
'use strict';
const VERSION='0.6.0', SCHEMA='ados.a7sem.reverse.checkpoint/0.6';
const STEPS=Object.freeze(['resonanz','ausdruck','echo','bedeutung','stabilisierung','emergenz','feldintegration']);
const AUTHORITY=Object.freeze({status:'BLOCK',reason:'NO_CANONICAL_ADOS_AUTHORITY',rootDeclared:false,policyBound:false,verified:false});
const text=v=>typeof v==='string'?v.trim():'';
const own=(o,k)=>!!o&&Object.prototype.hasOwnProperty.call(o,k);
const safeId=s=>/^[A-Za-z0-9:_-]{4,100}$/.test(text(s));
const isRef=s=>/^[A-Za-z0-9._:\/-]{4,120}$/.test(text(s));
const flat=(a)=>a.map(o=>Object.fromEntries(Object.entries(o).sort(([a],[b])=>a.localeCompare(b))));
function snapshot(caseInput={},opts={}){
  const c=E.norm(caseInput), detail=E.evaluate(c);
  const raw=opts.evidence&&typeof opts.evidence==='object'?opts.evidence:{};
  const evidence=STEPS.map((stage,i)=>{
    const e=raw[stage]&&typeof raw[stage]==='object'?raw[stage]:{};
    const status=['PRESENT','UNKNOWN','CONTRADICTED','REVOKED'].includes(e.status)?e.status:'UNKNOWN';
    return {step:i+1,stage,status,ref:text(e.ref),note:text(e.note)};
  });
  const reverse=Array.isArray(opts.reverse)?opts.reverse:[];
  const reverseRows=STEPS.slice().reverse().map((stage,i)=>{
    const row=reverse[i]&&typeof reverse[i]==='object'?reverse[i]:{};
    return {step:7-i,stage,claimRef:text(row.claimRef),sourceRef:text(row.sourceRef),checked:row.checked===true,contradicted:row.contradicted===true};
  });
  const statuses=[];
  if(c.safety!=='no')statuses.push(c.safety==='yes'?'SAFETY_EMERGENCY':'SAFETY_UNKNOWN');
  if(c.claimType==='diagnosis'||['diagnose','treat'].includes(c.nextAction))statuses.push('CLINICAL_SCOPE_BLOCK');
  if(detail.gate1.status!=='ALLOW')statuses.push('LOCAL_GATE1_'+detail.gate1.status);
  if(detail.gate2.status!=='ALLOW')statuses.push('LOCAL_GATE2_'+detail.gate2.status);
  evidence.forEach(e=>{
    if(e.status!=='PRESENT')statuses.push('A7_'+e.step+'_'+e.status);
    else if(!isRef(e.ref))statuses.push('A7_'+e.step+'_REF_MISSING');
  });
  reverseRows.forEach((r,i)=>{
    if(!r.checked||!isRef(r.claimRef)||!isRef(r.sourceRef))statuses.push('REVERSE_'+(7-i)+'_MISSING');
    if(r.contradicted)statuses.push('REVERSE_'+(7-i)+'_CONTRADICTED');
    if(evidence[6-i].ref&&r.sourceRef&&r.sourceRef!==evidence[6-i].ref)statuses.push('REVERSE_'+(7-i)+'_SOURCE_MISMATCH');
  });
  const localComplete=statuses.length===0;
  return Object.freeze({schema:SCHEMA,version:VERSION,caseRef:c.caseRef,kind:'RESEARCH_ONLY',purpose:'NON_CLINICAL_DOCUMENTATION',
    demo:{gate1:detail.gate1.status,gate2:detail.gate2.status},authority:AUTHORITY,
    evidence,reverse:reverseRows,findings:statuses,localComplete,
    localResult:localComplete?'REVIEW_READY_NONAUTHORITATIVE':c.safety==='yes'?'SAFETY_STOP':'REVIEW_REQUIRED',
    externalEffectAuthorized:false,clinicalDecisionAuthorized:false,engineCount:5,createAdditionalEngine:false});
}
function finite(input, opts={}, budget=7){
  const cap=Number.isInteger(budget)?Math.min(7,Math.max(1,budget)):7;
  const s=snapshot(input,opts),events=[];
  const seen=new Set();
  const stop=s.findings.includes('SAFETY_EMERGENCY')||s.findings.includes('CLINICAL_SCOPE_BLOCK');
  if(stop) return {...s,loop:{mode:'FINITE',limit:cap,iterations:0,steps:[],state:'BLOCK',reason:'SAFETY_OR_CLINICAL_BOUNDARY',nextStep:null}};
  for(let i=0;i<Math.min(cap,7);i++){
    const f=s.evidence[i],rv=s.reverse[6-i];
    const matched=f.status==='PRESENT'&&isRef(f.ref)&&rv.checked&&isRef(rv.sourceRef)&&rv.sourceRef===f.ref&&isRef(rv.claimRef)&&!rv.contradicted;
    const entry={iteration:i+1,step:f.step,stage:f.stage,evidenceRef:f.ref,reverseSourceRef:rv.sourceRef,transition:matched?'VERIFIED_LOCAL':'UNKNOWN_STOP',newEvidenceManufactured:false};
    events.push(entry);
    if(!matched)return {...s,loop:{mode:'FINITE',limit:cap,iterations:events.length,steps:events,state:'DELAY',reason:'MISSING_OR_CONFLICTING_EVIDENCE',nextStep:i+1}};
    if(seen.has(f.ref))return {...s,loop:{mode:'FINITE',limit:cap,iterations:events.length,steps:events,state:'DELAY',reason:'DUPLICATE_EVIDENCE_REF',nextStep:i+1}};
    seen.add(f.ref);
  }
  const complete=events.length===7;
  return {...s,loop:{mode:'FINITE',limit:cap,iterations:events.length,steps:events,state:complete&&s.localComplete?'REVIEW_READY_NONAUTHORITATIVE':'DELAY',reason:complete?'BOUNDED_REVIEW_COMPLETE':'BOUNDED_BUDGET_REACHED',nextStep:complete?null:events.length+1}};
}
// No unbounded runtime: every caller invocation performs <= 1 tick and returns a durable-serializable checkpoint.
// Without changed evidence version the loop cannot advance, preventing spurious self-improvement.
function continuousTick(input,opts={},previous=null,control={}){
  const time=Number.isFinite(control.now)?control.now:Date.now();
  const epoch=text(control.evidenceEpoch), consent=control.humanReview===true;
  const expires=Number.isFinite(control.expiresAt)?control.expiresAt:0;
  const base={schema:SCHEMA,mode:'FINITE_TICK_SUPERVISOR',issuedAt:time,authority:AUTHORITY,externalEffectAuthorized:false,
    engineCount:5,createAdditionalEngine:false,epoch,iterations:(Number(previous?.iterations)||0),status:'BLOCK',reason:'UNSPECIFIED'};
  if(control.revoked===true)return {...base,status:'BLOCK',reason:'REVOKED'};
  if(!expires||time>=expires)return {...base,status:'EXPIRED',reason:'EXPIRED_OR_MISSING_BOUND'};
  if(!consent)return {...base,status:'DELAY',reason:'HUMAN_REVIEW_REQUIRED'};
  if(!safeId(epoch))return {...base,status:'UNKNOWN',reason:'EVIDENCE_EPOCH_UNKNOWN'};
  if(previous?.epoch===epoch)return {...base,status:'DELAY',reason:'NO_NEW_EVIDENCE_NO_REENTRY'};
  if(Number(previous?.iterations)>=64)return {...base,status:'BLOCK',reason:'SUPERVISOR_QUOTA_EXHAUSTED'};
  const s=finite(input,opts,7);
  return {...base,iterations:base.iterations+1,status:s.loop.state==='BLOCK'?'BLOCK':'DELAY',
    reason:s.loop.state==='REVIEW_READY_NONAUTHORITATIVE'?'LOCAL_REVIEW_COMPLETED_CANONICAL_AUTHORITY_MISSING':s.loop.reason,
    localResult:s.loop.state,nextEligible:'NEW_HUMAN_REVIEWED_EVIDENCE_ONLY'};
}
function workbookRow(c){const x=E.evaluate(c);return {gate1:x.gate1.status,gate2:x.gate2.status,clinicalAllowed:false,canonical:'BLOCK'};}
return Object.freeze({VERSION,SCHEMA,STEPS,AUTHORITY,snapshot,finite,continuousTick,workbookRow});
});
