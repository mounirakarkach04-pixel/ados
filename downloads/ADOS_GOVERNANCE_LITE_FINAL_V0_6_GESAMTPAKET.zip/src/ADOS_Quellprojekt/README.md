# ADOS Governance Lite v0.5 — kontrollierter Forschungsprototyp

**Stand:** 23.10.2026 · **Status:** LOCAL RESEARCH ONLY · **Kein Medizinprodukt, keine klinische Zulassung, keine produktive PIGA-Gate-Autorität.**

Die Anwendung ist ein *digitaler Governance-Prüfpfad für fiktive Lehrfälle*. Sie stellt A–F-Fragen, lokale beispielhafte Gate-Status, ARGUS-7/A7SEM/Reverse-Eingaben und einen Glassbox-Demo-Export bereit. Keine KI, keine Cloud, keine Kontoanlage, keine automatische Übermittlung und keine laufenden API-Kosten. **Keine realen Gesundheits- oder Patientendaten eingeben.**

## Offline-Smartphone-Version

Die mitgelieferte Datei `ADOS_Governance_Lite_OFFLINE_DEMO_v0_5.html` lokal im geeigneten Browser öffnen. Der Browser muss lokale HTML-Dateien unterstützen. Die Datei ist einzeln funktionsfähig und besitzt eine restriktive `connect-src 'none'` Richtlinie; sie ruft keine Netzwerkdienste auf. Ihr Status für den *kanonischen* PIGA-Kernel bleibt immer `BLOCK`. Der JSON-Export ist **nicht verschlüsselt** und nicht signiert.

## Optionaler lokaler Signatur-/Replay-Test auf eigenem PC

Voraussetzung: Node.js 22+; **kein npm install notwendig**. Im Quellordner:

```bash
node server/local-bridge.mjs
```

Danach `http://127.0.0.1:8767/` im Browser des **gleichen Rechners** öffnen, ausschließlich fiktiven Fall anlegen und in der Ergebnisansicht „Lokale Test-Bridge prüfen“ anklicken. Der Server wird ausschließlich an die Loopback-Adresse gebunden. Er validiert Metadaten, signiert ein begrenztes `BLOCK`-Testrezept (Ed25519) und verwaltet verwendete Einmal-IDs/Widerrufe über Neustarts in `.ados-demo-state/nonce-ledger.jsonl`. Die Datei enthält nur Nonces/Referenz-IDs, keine Falltexte. **State-Verzeichnis sichern/als sensible Testmetadaten behandeln; nicht veröffentlichen.**

Ein exklusives Lock verhindert zwei gleichzeitige Testdienst-Prozesse. Nach einem Prozessabsturz muss ein übrig gebliebenes Lock vor einem erneuten Start von einer Fachperson überprüft werden; nicht automatisch auflösen. Beschädigte Ledger-Zeilen lassen den Dienst absichtlich mit BLOCK abbrechen. Dies ist ein atomarer, einzelprozessbezogener lokaler Prototyp, **kein produktionsreifes Multi-Worker-Nonce-Register und keine vollständige Recovery-Lösung**. Es existiert keine öffentliche Readback-/Revoke-API, kein Fernzugriff und keine produktive Aktionsfreigabe.

**Signaturgrenze:** Der temporäre öffentliche Testschlüssel wird vom selben Dienst geliefert. Das ist eine Integritätsprobe, kein unabhängiger Vertrauensanker. Bescheide werden nie als kanonische PIGA-Entscheidung ausgegeben. Die tatsächlich produktive Gate1/Gate2-Autorität bleibt gesperrt.

## PIGA Core K2.1.1 — Referenzidentität

Die UI ermöglicht zusätzlich einen rein lokalen SHA-256-Dateiabgleich mit dem im **PIGA K2.1.1 External Product Dossier v1.3.2** dokumentierten akzeptierten Bundle v0.7:

`PIGA_K2.1.1_RC_20260723_INTEGRATED_PROGRAM_CONTROL_v0.7.zip`

SHA-256 (dokumentiert): `a84001ad8cf3e5aef9123b33e641f6012b4ffc3b67814630121ebbd5bdc63605`.

Fester Scope-Hash (dokumentiert): `e3206c695a0c35b0e796a87bba5484fbb66267b83e16aa586f99cc50091e5c9f`.

**Ein Hash-Match beweist nur Byte-Identität**, nicht Freigabe, Scope-Gültigkeit für ADOS, signierte Inferenz-/Handlungsautorität, Widerrufsstatus oder klinische Validierung. Das Dossier beschränkt die Freigabe auf kontrollierte externe Evaluation/nichtproduktive Anpassung; Produktion ist nicht freigegeben. Eine vollständige kanonische Laufzeitanbindung ist **nicht hergestellt**.

## Tests reproduzieren

```bash
node tests/test-engine.cjs
node tests/test-v02.cjs
node tests/test-bridge.cjs
node tests/test-integrity.cjs
node tests/test-core-identity.cjs
node tests/test-local-bridge-v05.mjs
```

**90 automatisierte Testgruppen bestanden:** 15 Basisregeln, 10 v0.2-Erweiterungen, 17 Vertragstests, 5 Integritätsprüfungen, 10 Kerneldatei-Identitätsgrenzen, 33 dauerhafte Bridge-/HTTP-Prüfungen. Darin enthalten sind die 288 alten systematischen Demo-Kombinationen. Der Offline-Browser wurde mit 320, 390 und 1280 Pixeln erfolgreich geprüft. Lokaler Node-HTTP-Test bestanden. **Browser → localhost E2E bleibt offen**, da die isolierte Chromium-Umgebung einen Aufruf von `127.0.0.1` administrativ blockiert (`ERR_BLOCKED_BY_ADMINISTRATOR`).

## Architekturgrenze

Kein Zugriff auf Runtime-Secret, keine Änderung am bestehenden Pocket-Enterprise-Repository, keine sechste Engine, keine produktiven Maßnahmen, keine Diagnosen. Die bestehenden fünf Engines sind nur als Architekturreferenz dokumentiert, nicht in der App betrieben. Der aktuelle `piga-action-plane-admission-v1` kennt ADOS nicht als zulässige Aktionsklasse; die Demo benutzt diesen Dienst ausdrücklich nicht. Die verbindlichen Definitionen müssen vor einer Integration über kanonische Policy-/Resolver-Artefakte, autorisierte Signatur, Scope- und Revocation-Prüfungen implementiert und unabhängig überprüft werden.
