/* ADOS Governance Lite v0.5: fail-closed OFFLINE contract for a future canonical PIGA adapter.
   This component neither contains kernel rules nor calls an external service. */
(function(root, factory){ if(typeof module==='object' && module.exports)module.exports=factory(); else root.ADOSBridge=factory(); })(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const VERSION='0.5.0';
const CAPABILITY='ADOS_EVIDENCE_GOVERNANCE';
const STATUS=['ALLOW','DELAY','BLOCK','UNKNOWN','EXPIRED'];
const denied=(code,reason,status='BLOCK')=>({status,code,reason,authoritative:false});
const ready=()=>denied('MISSING_RUNTIME_AUTHORITY','Kanonischer PIGA-Kernel, vertrauenswürdige Signaturprüfung und Runtime-Autorität sind in dieser Offline-Demo nicht verbunden. Keine produktive Zulassung.');
const known=(x,arr)=>typeof x==='string'&&arr.includes(x);
const idSafe=x=>typeof x==='string'&&/^[A-Za-z0-9:_-]{8,128}$/.test(x);
function prepareRequest(input,options={}){
  if(!input || typeof input!=='object')return denied('INVALID_INPUT','Fehlendes Fallobjekt.');
  if(!known(input.safety,['yes','no','unknown']))return denied('INVALID_SAFETY','Sicherheitsstatus nicht normgerecht.');
  if(!known(input.claimType,['observation','working','diagnosis']))return denied('INVALID_CLAIM','Aussageart ungültig.');
  if(!known(input.nextAction,['document','clarify','diagnose','treat']))return denied('INVALID_ACTION','Handlung ungültig.');
  const now=Number.isFinite(options.now)?options.now:Date.now();
  const nonce=options.nonce;
  if(!idSafe(nonce))return denied('MISSING_SECURE_NONCE','Ohne kryptografisch erzeugte Einmal-ID wird kein zulassungsfähiger Antrag erzeugt.');
  if(input.claimType==='diagnosis'||['diagnose','treat'].includes(input.nextAction))return denied('CLINICAL_SCOPE_BLOCKED','Klinische Diagnose und Behandlung bleiben außerhalb dieses Demo-Adapters.');
  if(input.safety!=='no')return denied('SAFETY_NOT_CLEARED','Ungeklärte oder akute Sicherheit: kein Antragsübergang.');
  return {status:'PREPARED_ONLY',code:'LOCAL_NO_TRANSMISSION',authoritative:false,request:{schema:'ados-governance-admission-request/0.3',capability:CAPABILITY,nonce,requestId:'ADOS-'+nonce,createdAt:now,expiresAt:now+5*60*1000,scope:'DEMO_DOCUMENTATION_ONLY',caseRef:'FIKTIV',claimType:input.claimType,nextAction:input.nextAction,safety:input.safety,payload:'NOT_INCLUDED',evidenceRefCount:0}};
}
function createNonce(){
  if(typeof crypto==='undefined'||typeof crypto.getRandomValues!=='function')return null;
  const a=new Uint8Array(16);crypto.getRandomValues(a);return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('');
}
// This state is deliberately ephemeral (in-memory); it does NOT simulate durable, cross-worker nonces.
function verifierSession(){
  const consumed=new Set(),revoked=new Set();
  return {
    revoke(id){if(idSafe(id))revoked.add(id);},
    inspect(request,response,now=Date.now(),signatureVerified=false){
      if(!request||!response||typeof response!=='object')return denied('MISSING_ENVELOPE','Antrag oder Bescheid fehlt.');
      if(!idSafe(request.requestId)||!idSafe(request.nonce))return denied('INVALID_REQUEST','Ungültige Antragsidentität.');
      if(revoked.has(request.requestId))return denied('REVOKED','Antrag widerrufen.');
      if(consumed.has(request.requestId))return denied('NONCE_REPLAY','Einmal-Antrag wurde bereits verbraucht.');
      if(!Number.isFinite(now)||!Number.isFinite(request.expiresAt)||now>=request.expiresAt)return denied('EXPIRED_REQUEST','Antragsfrist abgelaufen.','EXPIRED');
      if(response.schema!=='ados-bridge-test-envelope/0.3' || response.requestId!==request.requestId || response.nonce!==request.nonce)return denied('REQUEST_MISMATCH','Bescheid nicht an Antrag gebunden.');
      if(response.scope!=='DEMO_DOCUMENTATION_ONLY'||request.scope!=='DEMO_DOCUMENTATION_ONLY')return denied('SCOPE_MISMATCH','Unzulässiger Geltungsbereich.');
      if(response.claimType!==request.claimType||response.nextAction!==request.nextAction)return denied('CLAIM_MISMATCH','Antrag und Bescheid weichen ab.');
      if(!Number.isFinite(response.expiresAt)||response.expiresAt<=now)return denied('EXPIRED_DECISION','Bescheid abgelaufen.','EXPIRED');
      if(!Number.isFinite(response.issuedAt)||response.issuedAt>now+30000 ||response.issuedAt<request.createdAt-30000)return denied('TIME_MISMATCH','Ungültiger Ausstellungszeitpunkt.');
      if(!idSafe(response.policyVersion)||!idSafe(response.keyId)||typeof response.signature!=='string'||response.signature.length<32)return denied('AUTHENTICITY_METADATA_MISSING','Versions-/Signaturinformationen fehlen.');
      if(!known(response.gate1,STATUS)||!known(response.gate2,STATUS))return denied('INVALID_STATUS','Bescheid enthält ungültige Zustände.');
      if(signatureVerified!==true)return denied('SIGNATURE_NOT_VERIFIED','Ohne externe kryptografische Signaturprüfung wird kein Bescheid anerkannt.');
      consumed.add(request.requestId);
      // Even after cryptographic verification a local adapter is not a clinical action gateway.
      const candidate=response.gate1==='ALLOW'&&response.gate2==='ALLOW'&&request.claimType==='observation'&&request.nextAction==='document';
      // A caller-provided boolean is never a real signature verifier. Never output ALLOW from this offline adapter.
      return {status:'UNKNOWN',code:candidate?'MOCK_CONTRACT_MATCH_NO_AUTHORITY':'NO_DEMO_ADMISSION',authoritative:false,consumed:true,reason:'Testvermerk zur lokalen Vertragsstruktur; selbst bei mock-bestätigter Signatur KEINE kanonische Freigabe.'};
    },
    stats(){return {consumed:consumed.size,revoked:revoked.size,persistence:'NONE'};}
  };
}
return {VERSION,CAPABILITY,ready,prepareRequest,createNonce,verifierSession};
});
