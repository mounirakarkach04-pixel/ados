/* ADOS Governance Lite v0.2.0 - deterministic demonstration rules.
   NOT the canonical PIGA kernel; NOT a diagnostic or medical device. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ADOSEngine = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = '0.5.0';
  const RULESET = 'ADOS-LITE-DEMO-RULES-0.2';
  const STATUS = Object.freeze({ALLOW:'ALLOW', DELAY:'DELAY', BLOCK:'BLOCK', UNKNOWN:'UNKNOWN', EXPIRED:'EXPIRED'});
  const GAP_TYPES = ['none', 'source', 'time', 'concept', 'alternative', 'safety', 'revision'];
  const A7 = [
    {key:'resonanz',name:'Resonanz',question:'Was war der erste wahrnehmbare Auslöser oder die erste Veränderung?'},
    {key:'ausdruck',name:'Ausdruck',question:'Was wurde wörtlich berichtet oder beobachtbar gezeigt?'},
    {key:'echo',name:'Echo',question:'Wie reagierte das Umfeld? Welche Rückkopplung gab es?'},
    {key:'bedeutung',name:'Bedeutung',question:'Welche Bedeutung wird zugeschrieben – und von wem?'},
    {key:'stabilisierung',name:'Stabilisierung',question:'Welche Wiederholungen, aufrechterhaltenden Bedingungen oder Schutzfaktoren sind bekannt?'},
    {key:'emergenz',name:'Emergenz',question:'Welches neue Muster oder welche Funktionsänderung zeigt sich?'},
    {key:'feldintegration',name:'Feldintegration',question:'Welche Lebensbereiche sind betroffen und wo liegen Gegenbeispiele?'}
  ];
  const ARGUS = [
    'Welche konkrete Beobachtung liegt vor, und welches Motiv wurde nur vermutet?',
    'Was sagt die Person wörtlich, und was ist kausal nicht ableitbar?',
    'Welche Aussage ist noch nicht geprüft und deshalb UNKNOWN?',
    'Ist eine Aussage widerlegt oder nur derzeit nicht zugelassen?',
    'Welche Wirkung ist erfasst, welche Urheberschaft wird bloß unterstellt?',
    'Welche plausible Gegenhypothese erklärt denselben Befund?',
    'Welcher Befund würde eine Neubewertung auslösen?'
  ];
  const emptyCase = () => ({
    caseRef:'FIKTIV-001', safety:'unknown', dangerNote:'',
    original:'', observed:'', interpretation:'', source:'', observedAt:'',
    alternative:'', counterEvidence:'',
    criticalGap:'none', gapNote:'',
    claimType:'observation', evidenceConfirmed:false,
    nextAction:'document', nextWhat:'', nextWho:'', nextWhen:'',
    reverseLink:'', reverseBreak:'',
    a7:Object.fromEntries(A7.map(a=>[a.key,''])),
    argus:Object.fromEntries(ARGUS.map((_,i)=>['a'+(i+1),''])),
    nsfRef:'', nsfStatus:'OPEN', nsfEvidence:'',
    reviewer:'', reviewed:false
  });
  const demoCase = () => Object.assign(emptyCase(), {
    caseRef:'FIKTIV-DEMOBEISPIEL', safety:'no',
    original:'„Seit zwei Wochen sage ich Treffen häufiger ab.“',
    observed:'Die Person berichtet abgesagte Treffen; unabhängige Überprüfung fehlt.',
    interpretation:'Ein depressiver Prozess könnte beteiligt sein; nicht bestätigt.',
    source:'Fiktives Gespräch, subjektive Selbstauskunft', observedAt:'Tag 1 (fiktiv)',
    alternative:'Schlafmangel oder situative Belastung.',
    counterEvidence:'Zeitlicher Verlauf, Schlaf und Belastung; Ausnahmen erfragen.',
    criticalGap:'alternative', gapNote:'Schlaf, Belastung und Verlauf noch ungeprüft.',
    claimType:'working', nextAction:'clarify',
    nextWhat:'Fachlich verantwortete Klärung der offenen Fragen dokumentieren.',
    nextWho:'Zuständige Fachperson', nextWhen:'Nächster vereinbarter Termin',
    reverseLink:'Rückzug laut Selbstaussage ist belegbar, Ursache offen.',
    reverseBreak:'Keine unabhängige Prüfung von Verlauf und Alternativen.'
  });
  const filled = x => typeof x === 'string' && x.trim().length > 0;
  const clean = (value, fallback) => typeof value === 'string' ? value : fallback;
  const norm = input => {
    const c = emptyCase(), obj = input && typeof input === 'object' ? input : {};
    for(const key of Object.keys(c)) {
      if (key === 'a7' || key === 'argus') {
        const o = obj[key] && typeof obj[key] === 'object' ? obj[key] : {};
        for(const k of Object.keys(c[key])) c[key][k] = clean(o[k], '');
      } else if (typeof c[key] === 'boolean') c[key] = obj[key] === true;
      else c[key] = clean(obj[key], c[key]);
    }
    if (!['yes','no','unknown'].includes(c.safety)) c.safety = 'unknown';
    if (!['observation','working','diagnosis'].includes(c.claimType)) c.claimType = 'working';
    if (!['document','clarify','diagnose','treat'].includes(c.nextAction)) c.nextAction = 'clarify';
    if (!GAP_TYPES.includes(c.criticalGap)) c.criticalGap = 'none';
    if (!['PASS','OPEN','FAIL','UNKNOWN'].includes(c.nsfStatus)) c.nsfStatus = 'UNKNOWN';
    return c;
  };
  const verdict = (status, label, reasons, restrictions) => ({status,label,reasons,restrictions});
  function evaluate(raw) {
    const c = norm(raw), missing = [];
    if (!filled(c.original)) missing.push('Originalwortlaut');
    if (!filled(c.observed)) missing.push('Beobachtung/Überprüfbarkeit');
    if (!filled(c.source)) missing.push('Quelle');
    if (!filled(c.observedAt)) missing.push('Zeitbezug');
    const hasBase = missing.length === 0;
    const hasCounter = filled(c.alternative) && filled(c.counterEvidence);
    let g1, g2, emergency=false;
    if(c.safety==='yes') {
      emergency=true;
      g1=verdict(STATUS.BLOCK, 'Routineprüfung ausgesetzt', ['Akute Gefährdung/Warnzeichen angegeben. Keine reguläre Inferenzprüfung fortsetzen.'], 'Etablierte fachliche Notfall- und Schutzverfahren haben Vorrang.');
      g2=verdict(STATUS.BLOCK, 'Routinehandlungen ausgesetzt', ['Akute Gefährdung/Warnzeichen angegeben.'], 'Keine Empfehlung zum Abwarten; unverzüglich zuständige Notfall-/Schutzwege nutzen.');
    } else if (c.safety==='unknown') {
      g1=c.claimType==='diagnosis'
        ?verdict(STATUS.BLOCK, 'Diagnose außerhalb der App', ['Diagnose ist unabhängig vom Sicherheitsstatus außerhalb des Demo-Funktionsumfangs.'], 'Keine App-Diagnose.')
        :verdict(STATUS.UNKNOWN, 'Sicherheit ungeklärt', ['Sicherheitsstatus ist nicht geklärt.'], 'Keine Freigabe aus der App.');
      g2=['diagnose','treat'].includes(c.nextAction)
        ?verdict(STATUS.BLOCK, 'Klinische Aktion außerhalb der App', ['Diagnose oder Therapie darf auch bei ungeklärter Sicherheit nicht durch die Demo freigegeben werden.'], 'Keine klinische Handlungsfreigabe.')
        :verdict(STATUS.DELAY, 'Sicherheitsklärung erforderlich', ['Vor einer Routinefortsetzung Sicherheitsstatus fachlich klären.'], 'Bei Anzeichen akuter Gefahr sofort etablierte Notfallwege.');
    } else {
      if(c.claimType === 'diagnosis') {
        g1=verdict(STATUS.BLOCK, 'Diagnostische Feststellung außerhalb der App', ['Das Demo-System gibt keine medizinischen/psychologischen Diagnosen frei.'], 'Nur eine entsprechend qualifizierte Fachperson kann eine klinische Entscheidung treffen.');
      } else if(!hasBase) {
        g1=verdict(STATUS.UNKNOWN, 'Befundgrundlage unvollständig', [`Fehlend: ${missing.join(', ')}.`], 'Keine ungestützte Schlussfolgerung.');
      } else if(!hasCounter) {
        g1=verdict(STATUS.DELAY, 'Gegenprüfung unvollständig', ['Alternative Erklärung und unterscheidender Beleg müssen dokumentiert werden.'], 'Vorläufige Dokumentation ist möglich, aber keine definitive Folgerung.');
      } else if(c.criticalGap !== 'none') {
        g1=verdict(STATUS.DELAY, 'Entscheidungsrelevante Lücke offen', ['Offene kritische Lücke: '+c.criticalGap+(filled(c.gapNote)?' — '+c.gapNote:'')], 'Keine Entscheidung auf ungeprüfter Grundlage.');
      } else if(c.claimType === 'working') {
        g1=verdict(STATUS.DELAY, 'Arbeitshypothese bleibt vorläufig', ['Eine Arbeitshypothese wird im Prototyp nicht als gesicherte Diagnose zugelassen.'], 'Fachliche Prüfung außerhalb dieses Prototyps erforderlich.');
      } else if(!c.evidenceConfirmed) {
        g1=verdict(STATUS.DELAY, 'Quellenprüfung ausstehend', ['Quellen und Zeitbezug sind erfasst, aber die Quellenprüfung ist nicht bestätigt.'], 'Bestätigung ist eine Dokumentationshandlung, keine klinische Validierung.');
      } else {
        g1=verdict(STATUS.ALLOW, 'Nur beobachtungsbezogene Dokumentation', ['Originalwortlaut, Beobachtung, Quelle, Zeitbezug und Gegenprüfung sind dokumentiert.'], 'ALLOW betrifft ausschließlich die Dokumentation einer Beobachtung, niemals eine Diagnose.');
      }
      if(c.nextAction === 'diagnose' || c.nextAction === 'treat') {
        g2=verdict(STATUS.BLOCK, 'Klinische Maßnahmen nicht durch Demo freigegeben', ['Diagnostische oder therapeutische Handlungen liegen außerhalb der Zweckbestimmung.'], 'Fachliche Verantwortung, gesetzliche und klinische Verfahren bleiben unberührt.');
      } else if(c.nextAction === 'clarify') {
        g2=verdict(STATUS.DELAY, 'Weitere fachliche Klärung dokumentieren', ['Der nächste Klärungsschritt ist ein menschlich zu planender Prozess.'], 'Keine medizinische Handlungsfreigabe aus diesem Status.');
      } else if(!filled(c.nextWhat) || !filled(c.nextWho)) {
        g2=verdict(STATUS.DELAY, 'Dokumentationsschritt unvollständig', ['Nächster Schritt und zuständige Person fehlen.'], 'Ohne Zuständigkeit keine Prozessfreigabe.');
      } else {
        g2=verdict(STATUS.ALLOW, 'Dokumentationsschritt erfasst', ['Zweck und Zuständigkeit des nichtklinischen Dokumentationsschritts sind angegeben.'], 'Keine Freigabe einer Diagnose, Behandlung oder externen Aktion.');
      }
    }
    const trace=makeTrace(c,{hasBase,hasCounter,missing},g1,g2);
    return {
      engine:VERSION, ruleset:RULESET, trace, scope:'Nichtklinischer Demo-Prüfworkflow mit fiktiven Fällen',
      safety: c.safety, emergency, gate1:g1, gate2:g2,
      gaps:missing,
      nsfResolvedStatus:(c.nsfStatus==='PASS' && (!filled(c.nsfRef)||!filled(c.nsfEvidence)))?'UNKNOWN':c.nsfStatus,
      warnings:[
        ...(c.criticalGap !== 'none' && !filled(c.gapNote) ? ['Kritische Lücke ist markiert, aber nicht erläutert.']:[]),
        ...(c.nsfStatus === 'PASS' && (!filled(c.nsfEvidence)||!filled(c.nsfRef)) ? ['NSF-PASS ohne Kennung und Beleg wird für diesen Demo-Report als UNKNOWN behandelt.']:[]),
        ...(c.reviewer && !c.reviewed ? ['Prüfername dokumentiert, menschliche Prüfung nicht bestätigt.']:[])
      ]
    };
  }

  /* These IDs describe THIS local demo only; they are not canonical PIGA rules. */
  function makeTrace(c,ctx,g1,g2){
    const check=(id,title,state,note)=>({ruleId:id,title,status:state,explanation:note});
    const safe=c.safety==='no';
    return [
      check('DEMO-S01','Sicherheit zuerst',safe?'DOCUMENTED':c.safety==='yes'?'STOP':'OPEN',
        c.safety==='yes'?'Akute Warnzeichen angegeben; Routineprüfung ausgesetzt.':c.safety==='unknown'?'Sicherheitsstatus offen.':'Im Testfall keine Warnzeichen angegeben; kein realer Sicherheitsausschluss.'),
      check('DEMO-E01','Belegkette und Provenienz',ctx.hasBase?'DOCUMENTED':'OPEN',
        ctx.hasBase?'Originaltext, Beobachtung, Quelle und Zeitbezug sind ausgefüllt.':'Fehlt: '+ctx.missing.join(', ')),
      check('DEMO-C01','Gegenhypothese',ctx.hasCounter?'DOCUMENTED':'OPEN',
        ctx.hasCounter?'Alternative und möglicher unterscheidender Gegenbeleg genannt.':'Alternative und/oder möglicher Gegenbeleg fehlen.'),
      check('DEMO-U01','Entscheidungsrelevante Unsicherheit',c.criticalGap==='none'?'NO_GAP_MARKED':'OPEN',
        c.criticalGap==='none'?'Keine entscheidungsrelevante Lücke markiert (Selbstauskunft).':'Offener Punkt: '+c.criticalGap),
      check('DEMO-G01','Gate 1 – begrenzte Inferenzzulassung',g1.status,g1.reasons.join(' ')),
      check('DEMO-G02','Gate 2 – begrenzte Vorgangszulassung',g2.status,g2.reasons.join(' ')),
      check('DEMO-N01','NSF-325 – optionale Referenz',c.nsfStatus==='PASS'&&(!filled(c.nsfRef)||!filled(c.nsfEvidence))?'UNKNOWN':c.nsfStatus,
        c.nsfStatus==='PASS'&&(!filled(c.nsfRef)||!filled(c.nsfEvidence))?'Nicht belegter PASS wird im Report nicht übernommen.':'Referenzfeld ist optional; kein klinischer Gesamtscore.')
    ];
  }
  function scenarios(){
    const make=(id,title,note,changes,expected)=>{
      const c=Object.assign(demoCase(),changes);c.caseRef=id;
      return {id,title,note,case:c,expected};
    };
    return [
      make('FIKTIV-S01','Ungeklärte Sicherheit','Sicherheitsstatus nicht erhoben – keine Freigabe.',{safety:'unknown'},['UNKNOWN','DELAY']),
      make('FIKTIV-S02','Akute Warnzeichen','Notfallvorrang unterbricht den Routineworkflow.',{safety:'yes',dangerNote:'Fiktiver Sicherheitsalarm.'},['BLOCK','BLOCK']),
      make('FIKTIV-S03','Fehlende Quelle','Original und Beobachtung da, Quellenangabe fehlt.',{source:''},['UNKNOWN','DELAY']),
      make('FIKTIV-S04','Offene Gegenhypothese','Entscheidende Alternative bleibt ungeprüft.',{claimType:'observation',evidenceConfirmed:true,criticalGap:'alternative'},['DELAY','DELAY']),
      make('FIKTIV-S05','Dokumentation ausreichend','Nur nichtklinische Beobachtungsdokumentation – kein Diagnoseurteil.',{claimType:'observation',evidenceConfirmed:true,criticalGap:'none',nextAction:'document'},['ALLOW','ALLOW']),
      make('FIKTIV-S06','Unzulässige klinische Aktion','Diagnose und Behandlung dürfen nicht durch die Demo zugelassen werden.',{claimType:'diagnosis',nextAction:'treat'},['BLOCK','BLOCK'])
    ];
  }
  function runScenarioChecks(){
    return scenarios().map(test=>{
      const r=evaluate(test.case);
      const actual=[r.gate1.status,r.gate2.status];
      return {id:test.id,title:test.title,expected:test.expected,actual,pass:test.expected.every((x,i)=>x===actual[i])};
    });
  }
  return {VERSION, RULESET, STATUS, A7, ARGUS, emptyCase, demoCase, norm, evaluate, scenarios, runScenarioChecks};
});
