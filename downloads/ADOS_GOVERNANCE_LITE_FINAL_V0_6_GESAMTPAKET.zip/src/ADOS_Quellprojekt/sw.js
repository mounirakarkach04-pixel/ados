// ADOS Lite: cache of fixed static application shell only; no case data are cached.
const CACHE='ados-lite-shell-v0.5.0';const ASSETS=['./','./index.html','./styles.css','./app.js','./engine.js','./kernel-bridge.js','./integrity.js','./core-identity.js','./manifest.webmanifest','./icon.svg'];
self.addEventListener('install',ev=>{ev.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));self.skipWaiting()});
self.addEventListener('activate',ev=>{ev.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('ados-lite-shell-')&&k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',ev=>{if(ev.request.method!=='GET')return;const url=new URL(ev.request.url);if(url.origin!==self.location.origin||!url.pathname.startsWith(new URL(self.registration.scope).pathname))return;ev.respondWith(caches.match(ev.request).then(res=>res||fetch(ev.request)))});
