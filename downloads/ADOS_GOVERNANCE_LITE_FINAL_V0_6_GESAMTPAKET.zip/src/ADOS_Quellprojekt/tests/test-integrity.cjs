'use strict';
const assert=require('node:assert/strict');const I=require('../integrity.js');
(async()=>{
let n=0;async function test(name,fn){await fn();n++;console.log('PASS',name)}
await test('canonical order independent',()=>assert.equal(I.canonical({b:1,a:{z:3,c:1}}),I.canonical({a:{c:1,z:3},b:1})));
await test('SHA256 supports deterministic digest',async()=>assert.equal((await I.sha256('abc')),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'));
await test('seal and verify',async()=>{const s=await I.seal({fiktiv:true,case:'demo'});assert.equal((await I.verify(s)).ok,true);assert.equal(s.integrity.kind,'untrusted_local_checksum')});
await test('payload tamper detected',async()=>{const s=await I.seal({a:3});s.payload.a=4;assert.equal((await I.verify(s)).reason,'HASH_MISMATCH')});
await test('checksum removal detected',async()=>{const s=await I.seal({a:3});delete s.integrity.digest;assert.equal((await I.verify(s)).ok,false)});
console.log(`PASS ${n} integrity test groups`);
})().catch(e=>{console.error(e);process.exitCode=1});
