const assert=require('node:assert/strict');
const g=require('../engine.js');
const fixture=()=>g.demoCase();
let tests=0;
function test(name,fn){try{fn();console.log('PASS',name);tests++}catch(e){console.error('FAIL',name,e);process.exitCode=1}}
test('unknown safety blocks admission',()=>{const d=fixture();d.safety='unknown';const x=g.evaluate(d);assert.equal(x.gate1.status,'UNKNOWN');assert.equal(x.gate2.status,'DELAY')});
test('danger stops routine and never returns ALLOW',()=>{const d=fixture();d.safety='yes';d.nextAction='document';assert.equal(g.evaluate(d).gate1.status,'BLOCK');assert.equal(g.evaluate(d).gate2.status,'BLOCK')});
test('diagnostic conclusion never admitted',()=>{const d=fixture();d.safety='no';d.criticalGap='none';d.claimType='diagnosis';d.evidenceConfirmed=true;assert.equal(g.evaluate(d).gate1.status,'BLOCK')});
test('clinical treatment never admitted',()=>{const d=fixture();d.nextAction='treat';assert.equal(g.evaluate(d).gate2.status,'BLOCK')});
test('absence of original evidence is unknown',()=>{const d=fixture();d.original='';assert.equal(g.evaluate(d).gate1.status,'UNKNOWN')});
test('without counterhypothesis delay',()=>{const d=fixture();d.criticalGap='none';d.alternative='';assert.equal(g.evaluate(d).gate1.status,'DELAY')});
test('critical gap delays even if otherwise documented',()=>{const d=fixture();d.claimType='observation';d.evidenceConfirmed=true;assert.equal(g.evaluate(d).gate1.status,'DELAY')});
test('documented observation receives narrow ALLOW',()=>{const d=fixture();d.criticalGap='none';d.claimType='observation';d.evidenceConfirmed=true;const x=g.evaluate(d);assert.equal(x.gate1.status,'ALLOW');assert.match(x.gate1.restrictions,/niemals eine Diagnose/)});
test('documentation action receives narrow ALLOW',()=>{const d=fixture();const x=g.evaluate(d);assert.equal(x.gate2.status,'DELAY');d.nextAction='document';assert.equal(g.evaluate(d).gate2.status,'ALLOW')});
test('missing next-step owner delays documentation',()=>{const d=fixture();d.nextAction='document';d.nextWho='';assert.equal(g.evaluate(d).gate2.status,'DELAY')});
test('nsf pass without evidence warns',()=>{const d=fixture();d.nsfRef='N1.1.2';d.nsfStatus='PASS';const x=g.evaluate(d);assert(x.warnings.some(x=>x.includes('NSF-PASS')))});
test('status vocabulary unchanged',()=>{assert.deepEqual(Object.values(g.STATUS),['ALLOW','DELAY','BLOCK','UNKNOWN','EXPIRED'])});
test('seven perspectives',()=>{assert.equal(g.A7.length,7);assert.equal(g.ARGUS.length,7)});
test('malformed input is fail safe',()=>{assert.equal(g.evaluate(null).gate1.status,'UNKNOWN');assert.equal(g.evaluate({safety:'weird'}).gate2.status,'DELAY')});
test('exhaust all safety/action/claim and check prohibited ALLOW',()=>{
for(const safety of ['yes','unknown','no'])for(const claimType of ['diagnosis','working','observation'])for(const nextAction of ['diagnose','treat','document','clarify']){
const d=fixture();Object.assign(d,{safety,claimType,nextAction,criticalGap:'none',evidenceConfirmed:true});const x=g.evaluate(d);
if(safety==='yes')assert.notEqual(x.gate1.status,'ALLOW');
if(claimType==='diagnosis' && safety==='no')assert.equal(x.gate1.status,'BLOCK');
if(['diagnose','treat'].includes(nextAction)&&safety==='no')assert.equal(x.gate2.status,'BLOCK');
}
});
console.log(`${tests} tests passed.`);
