import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createLocalService,createServer} from '../server/local-bridge.mjs';
let count=0;function test(name,fn){fn();count++;console.log('PASS',name)}
let now=1792764600000;const svc=createLocalService(()=>now);
const sample=()=>{const nonce=crypto.randomBytes(16).toString('hex');return {schema:'ados-governance-admission-request/0.3',capability:'ADOS_EVIDENCE_GOVERNANCE',nonce,requestId:'ADOS-'+nonce,createdAt:now,expiresAt:now+300000,scope:'DEMO_DOCUMENTATION_ONLY',caseRef:'FIKTIV',claimType:'observation',nextAction:'document',safety:'no',payload:'NOT_INCLUDED',evidenceRefCount:0}};
const inspect=packet=>JSON.parse(packet.signedPayload);
test('no real PIGA kernel status remains BLOCK',()=>assert.equal(svc.status().kernelStatus,'BLOCK'));
test('only 5 existing engines',()=>assert.equal(svc.status().engineCount,5));
test('no new engines',()=>assert.equal(svc.status().additionalEngineCreated,false));
test('only BLOCK signed receipts',()=>{const r=svc.admit(sample());assert.equal(inspect(r).status,'BLOCK');assert.equal(inspect(r).authoritative,false)});
test('test receipt is cryptographically verifiable',()=>assert.equal(svc.verifyReceipt(svc.admit(sample())),true));
test('receipt tampering is detected',()=>{const r=svc.admit(sample());r.signedPayload=r.signedPayload.replace('BLOCK','ALLOW');assert.equal(svc.verifyReceipt(r),false)});
test('wrong signature is rejected',()=>{const r=svc.admit(sample());r.signature=crypto.randomBytes(64).toString('base64');assert.equal(svc.verifyReceipt(r),false)});
test('same nonce replay blocked',()=>{const r=sample();svc.admit(r);assert.equal(inspect(svc.admit(r)).reason,'REPLAY')});
test('locally revoked request blocked',()=>{const r=sample();svc.revoke(r.requestId);assert.equal(inspect(svc.admit(r)).reason,'REVOKED')});
test('expired request blocked',()=>{const r=sample();r.expiresAt=now-1;assert.equal(inspect(svc.admit(r)).reason,'TIME_INVALID')});
test('stale createdAt blocked',()=>{const r=sample();r.createdAt-=121000;r.expiresAt=r.createdAt+300000;assert.equal(inspect(svc.admit(r)).reason,'CLOCK_SKEW')});
test('future createdAt blocked',()=>{const r=sample();r.createdAt+=20000;r.expiresAt=r.createdAt+300000;assert.equal(inspect(svc.admit(r)).reason,'CLOCK_SKEW')});
test('clinical claim blocked',()=>{const r=sample();r.claimType='diagnosis';assert.equal(inspect(svc.admit(r)).reason,'CLINICAL_SCOPE_BLOCKED')});
test('clinical action blocked',()=>{const r=sample();r.nextAction='treat';assert.equal(inspect(svc.admit(r)).reason,'CLINICAL_SCOPE_BLOCKED')});
test('unknown safety blocked',()=>{const r=sample();r.safety='unknown';assert.equal(inspect(svc.admit(r)).reason,'SAFETY_NOT_CLEARED')});
test('wrong caseRef blocked',()=>{const r=sample();r.caseRef='patient-123';assert.equal(inspect(svc.admit(r)).reason,'DATA_SCOPE_BLOCK')});
test('added narrative blocked',()=>{const r=sample();r.narrative='irrelevant';assert.equal(inspect(svc.admit(r)).reason,'UNEXPECTED_FIELDS')});
test('nonce not random-shaped blocked',()=>{const r=sample();r.nonce='weak';assert.equal(inspect(svc.admit(r)).reason,'NONCE_OR_ID_INVALID')});
test('readback returns known receipt',()=>{const r=sample();svc.admit(r);assert(svc.readback(r.requestId))});
test('readback unknown returns null',()=>assert.equal(svc.readback('ADOS-00000000000000000000000000000000'),null));
test('nonce store not persistent',()=>assert.equal(svc.status().persistentReplayProtection,false));

const livePort=8767;const server=createServer({service:svc,port:livePort});
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(livePort,'127.0.0.1',resolve)});
try{
 let res=await fetch(`http://127.0.0.1:${livePort}/api/ados/bridge/status`);test('loopback status 200',()=>assert.equal(res.status,200));
 res=await fetch(`http://127.0.0.1:${livePort}/api/ados/bridge/admission`,{method:'POST',headers:{'content-type':'application/json','x-ados-local-demo':'1','origin':`http://127.0.0.1:${livePort}`},body:JSON.stringify(sample())});
 const receipt=await res.json();test('local HTTP receipt signed BLOCK',()=>assert.equal(inspect(receipt).status,'BLOCK'));test('HTTP receipt signature verified',()=>assert(svc.verifyReceipt(receipt)));
 res=await fetch(`http://127.0.0.1:${livePort}/api/ados/bridge/admission`,{method:'POST',headers:{'content-type':'application/json','x-ados-local-demo':'1','origin':'http://evil.local'},body:JSON.stringify(sample())});test('foreign origin denied',()=>assert.equal(res.status,403));
 res=await fetch(`http://127.0.0.1:${livePort}/api/ados/bridge/admission`,{method:'POST',headers:{'content-type':'application/json','origin':`http://127.0.0.1:${livePort}`},body:JSON.stringify(sample())});test('missing explicit demo header denied',()=>assert.equal(res.status,415));
 res=await fetch(`http://127.0.0.1:${livePort}/api/ados/bridge/admission`,{method:'POST',headers:{'content-type':'application/json','x-ados-local-demo':'1','origin':`http://127.0.0.1:${livePort}`},body:JSON.stringify({...sample(),description:'x'.repeat(5000)})});test('oversized envelope denied',()=>assert.equal(res.status,413));
 res=await fetch(`http://127.0.0.1:${livePort}/index.html`);test('static app served',()=>assert.equal(res.status,200));
 res=await fetch(`http://127.0.0.1:${livePort}/../package.json`);test('arbitrary static file not accessible',()=>assert.equal(res.status,404));
 console.log('SUCCESS '+count+' local bridge security and transport checks');
}finally{await new Promise(resolve=>server.close(resolve))}
