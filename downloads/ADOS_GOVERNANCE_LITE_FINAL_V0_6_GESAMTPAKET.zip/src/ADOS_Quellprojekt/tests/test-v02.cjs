const assert=require('node:assert/strict');
const E=require('../engine.js');
let n=0;
function test(title,fn){fn();n++;console.log('PASS',title)}
const fixture=()=>E.demoCase();
test('version and demo ruleset clearly distinct from canonical kernel',()=>{
 assert.equal(E.VERSION,'0.5.0');assert.match(E.RULESET,/LITE-DEMO/)
});
test('six scenarios are reproducible',()=>{
 const r=E.runScenarioChecks();assert.equal(r.length,6);assert(r.every(x=>x.pass),JSON.stringify(r));
});
test('rule trace always exists and uses unique DEMO rule IDs',()=>{
 const x=E.evaluate(fixture());assert.equal(x.ruleset,E.RULESET);assert.equal(x.trace.length,7);
 assert.equal(new Set(x.trace.map(x=>x.ruleId)).size,x.trace.length);
 assert(x.trace.every(x=>x.ruleId.startsWith('DEMO-')));
});
test('NSF PASS with no evidence downgraded only in reported reference status',()=>{
 const d=fixture();d.nsfRef='N1.1.9';d.nsfStatus='PASS';d.nsfEvidence='';
 const x=E.evaluate(d);assert.equal(x.nsfResolvedStatus,'UNKNOWN');
 assert.equal(x.trace.find(v=>v.ruleId==='DEMO-N01').status,'UNKNOWN');
 assert.equal(d.nsfStatus,'PASS');
});
test('NSF valid reference still not a clinical score',()=>{
 const d=fixture();d.nsfRef='N1.1.9';d.nsfStatus='PASS';d.nsfEvidence='BELEG-FIKTIV';
 assert.equal(E.evaluate(d).nsfResolvedStatus,'PASS');
});
test('no safety info plus diagnostic claim is always BLOCK',()=>{
 const d=fixture();d.safety='unknown';d.claimType='diagnosis';assert.equal(E.evaluate(d).gate1.status,'BLOCK');
});
test('no safety info plus clinical action is always BLOCK',()=>{
 for(const nextAction of ['diagnose','treat']){
 const d=fixture();d.safety='unknown';d.nextAction=nextAction;
 assert.equal(E.evaluate(d).gate2.status,'BLOCK')}
});
test('emergency dominates all claims and actions',()=>{
 const d=fixture();d.safety='yes';d.claimType='observation';d.nextAction='document';d.criticalGap='none';d.evidenceConfirmed=true;
 assert.deepEqual([E.evaluate(d).gate1.status,E.evaluate(d).gate2.status],['BLOCK','BLOCK']);
});
test('no hidden clinical ALLOW across 288 policy combinations',()=>{
 let combos=0;
 for(const safety of ['yes','unknown','no'])for(const claimType of ['observation','working','diagnosis'])for(const nextAction of ['document','clarify','diagnose','treat'])for(const confirmed of [true,false])for(const gap of ['none','source','alternative','safety']){
  const d=fixture();Object.assign(d,{safety,claimType,nextAction,evidenceConfirmed:confirmed,criticalGap:gap});const x=E.evaluate(d);combos++;
  if(claimType==='diagnosis')assert.notEqual(x.gate1.status,'ALLOW');
  if(['diagnose','treat'].includes(nextAction))assert.notEqual(x.gate2.status,'ALLOW');
  if(safety!=='no')assert.notEqual(x.gate1.status,'ALLOW');
  if(safety!=='no')assert.notEqual(x.gate2.status,'ALLOW');
  if(gap!=='none' && x.gate1.status==='ALLOW')assert.fail('ALLOW despite critical gap');
 }
 assert.equal(combos,288)
});
test('input normalization fails closed and does not mutate input',()=>{
 const d={safety:'bad',claimType:'diagnosis',nextAction:'treat',a7:{resonanz:45},argus:{a1:99}};
 const original=JSON.stringify(d);const x=E.evaluate(d);
 assert.notEqual(x.gate1.status,'ALLOW');assert.notEqual(x.gate2.status,'ALLOW');assert.equal(JSON.stringify(d),original)
});
console.log(`PASS ${n} additional v0.2 test groups`);
