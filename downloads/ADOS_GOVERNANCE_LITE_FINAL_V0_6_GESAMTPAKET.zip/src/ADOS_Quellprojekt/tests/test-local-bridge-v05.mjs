import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {createLocalService,createServer,PORT,SCHEMA} from '../server/local-bridge.mjs';

let now=1792764600000,n=0;const folder=fs.mkdtempSync(path.join(os.tmpdir(),'ados-v05-test-'));
const check=(name,callback)=>{callback();n++;console.log('PASS',name)};
const sample=()=>{const nonce=crypto.randomBytes(16).toString('hex');return {schema:'ados-governance-admission-request/0.3',capability:'ADOS_EVIDENCE_GOVERNANCE',nonce,requestId:'ADOS-'+nonce,createdAt:now,expiresAt:now+300000,scope:'DEMO_DOCUMENTATION_ONLY',caseRef:'FIKTIV',claimType:'observation',nextAction:'document',safety:'no',payload:'NOT_INCLUDED',evidenceRefCount:0}};
const body=r=>JSON.parse(r.signedPayload);
let svc=createLocalService({clock:()=>now,stateFolder:folder});
try{
 check('kernel strictly BLOCK',()=>assert.equal(svc.status().kernelStatus,'BLOCK'));
 check('five existing engines not expanded',()=>{assert.equal(svc.status().engineCount,5);assert.equal(svc.status().additionalEngineCreated,false)});
 check('no clinical data permission',()=>assert.equal(svc.status().patientDataAllowed,false));
 check('persistent nonce protection advertised only in local test',()=>assert.equal(svc.status().persistentReplayProtection,true));
 check('same-origin test-only key not trusted for canonical admission',()=>assert.equal(svc.status().publicKeyTrusted,false));
 const r=sample(),first=svc.admit(r);
 check('only signed test BLOCK responses',()=>{assert.equal(body(first).status,'BLOCK');assert.equal(body(first).schema,SCHEMA);assert.equal(body(first).authoritative,false)});
 check('signed local receipt validates with ephemeral session key',()=>assert.equal(svc.verifyReceipt(first),true));
 check('tampered signed payload rejected',()=>assert.equal(svc.verifyReceipt({...first,signedPayload:first.signedPayload.replace('BLOCK','ALLOW')}),false));
 check('tampered signature rejected',()=>assert.equal(svc.verifyReceipt({...first,signature:crypto.randomBytes(64).toString('base64')}),false));
 check('same-request replay is blocked',()=>assert.equal(body(svc.admit(r)).reason,'REPLAY'));
 check('ledger persists nonce without clinical content',()=>{const text=fs.readFileSync(path.join(folder,'nonce-ledger.jsonl'),'utf8');assert(text.includes(r.nonce));assert(!text.includes('interpretation'))});
 const revoked=sample();svc.revoke(revoked.requestId);
 check('revoked request blocked',()=>assert.equal(body(svc.admit(revoked)).reason,'REVOKED'));
 check('second service same ledger fails closed while locked',()=>assert.throws(()=>createLocalService({clock:()=>now,stateFolder:folder}),/STATE_ALREADY_LOCKED/));
 check('nonce and revocation survive restart',()=>{
   svc.close();svc=createLocalService({clock:()=>now,stateFolder:folder});
   assert.equal(body(svc.admit(r)).reason,'REPLAY');assert.equal(body(svc.admit(revoked)).reason,'REVOKED');
 });
 check('unknown safety blocked',()=>{const v=sample();v.safety='unknown';assert.equal(body(svc.admit(v)).reason,'SAFETY_NOT_CLEARED')});
 check('clinical action blocked',()=>{const v=sample();v.nextAction='treat';assert.equal(body(svc.admit(v)).reason,'CLINICAL_SCOPE_BLOCKED')});
 check('diagnosis assertion blocked',()=>{const v=sample();v.claimType='diagnosis';assert.equal(body(svc.admit(v)).reason,'CLINICAL_SCOPE_BLOCKED')});
 check('health narratives rejected',()=>{const v=sample();v.narrative='Fictitious narrative';assert.equal(body(svc.admit(v)).reason,'UNEXPECTED_FIELDS')});
 check('real caseRef rejected',()=>{const v=sample();v.caseRef='REAL-001';assert.equal(body(svc.admit(v)).reason,'DATA_SCOPE_BLOCK')});
 check('invalid nonce rejected',()=>{const v=sample();v.nonce='weak';assert.equal(body(svc.admit(v)).reason,'NONCE_OR_ID_INVALID')});
 check('expired rejected',()=>{const v=sample();v.expiresAt=now-100;assert.equal(body(svc.admit(v)).reason,'TIME_INVALID')});
 check('stale timestamp rejected',()=>{const v=sample();v.createdAt=now-300000;v.expiresAt=now-1;assert.equal(body(svc.admit(v)).reason,'CLOCK_SKEW')});
 const server=createServer({service:svc,port:PORT});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(PORT,'127.0.0.1',resolve)});
 try{
  const url=`http://127.0.0.1:${PORT}`;
  const send=(v,headers={})=>fetch(url+'/api/ados/bridge/admission',{method:'POST',headers:{'content-type':'application/json','x-ados-local-demo':'1','origin':url,...headers},body:JSON.stringify(v)});
  let res=await fetch(url+'/api/ados/bridge/status');check('local status served',()=>assert.equal(res.status,200));
  res=await send(sample());const obj=await res.json();check('HTTP receipt remains signed BLOCK',()=>{assert.equal(res.status,200);assert.equal(body(obj).status,'BLOCK');assert(svc.verifyReceipt(obj))});
  res=await send(sample(),{origin:'http://evil.example'});check('different Origin forbidden',()=>assert.equal(res.status,403));
  const hostMismatchStatus=await new Promise((resolve,reject)=>{const q=http.request({hostname:'127.0.0.1',port:PORT,path:'/api/ados/bridge/status',headers:{Host:'localhost:8767'}},a=>{a.resume();resolve(a.statusCode)});q.on('error',reject);q.end()});
  check('DNS rebinding Host header forbidden',()=>assert.equal(hostMismatchStatus,403));
  res=await fetch(url+'/api/ados/bridge/admission',{method:'POST',headers:{origin:url,'content-type':'application/json'},body:JSON.stringify(sample())});check('explicit demo header required',()=>assert.equal(res.status,415));
  res=await send({...sample(),extra:'a'.repeat(5000)});check('oversized payload rejected',()=>assert.equal(res.status,413));
  res=await fetch(url+'/index.html');check('app shell served same origin',()=>assert.equal(res.status,200));
  res=await fetch(url+'/core-identity.js');check('identity checker served same origin',()=>assert.equal(res.status,200));
  res=await fetch(url+'/api/ados/bridge/revoke/anything');check('no unauthenticated readback or revoke API exposed',()=>assert.equal(res.status,404));
  res=await fetch(url+'/../package.json');check('no arbitrary file read',()=>assert.equal(res.status,404));
 }finally{await new Promise(resolve=>server.close(resolve))}
 svc.close();
 // Corruption cannot reset nonce and must BLOCK service startup
 fs.appendFileSync(path.join(folder,'nonce-ledger.jsonl'),'invalid-json\n');
 check('corrupted replay ledger prevents startup',()=>assert.throws(()=>createLocalService({clock:()=>now,stateFolder:folder}),/STATE_LEDGER_CORRUPTED/));
 console.log('SUCCESS',n,'v0.5 durability, provenance and HTTP security tests');
}finally{svc.close();fs.rmSync(folder,{recursive:true,force:true})}
