'use strict';
(()=>{
const L=window.ADOSGovernedLoop;
const E=window.ADOSEngine, B=window.ADOSBridge, I=window.ADOSIntegrity, C=window.ADOSCoreIdentity; if(!E||!B||!I||!C){alert('Prüfengine, Kernel-Adapter oder Integritätsmodul fehlt');return;}
const pages=['intro','a','b','c','d','e','f','depth','review'];
const byId=id=>document.getElementById(id);
let latestLoop=null, latestTick=null;
let data=E.emptyCase(), current='intro', started=false, events=[], lastGate='';
const now=()=>new Date().toISOString();
const log=event=>{events.push({at:now(),event}); if(events.length>250)events=events.slice(-250);};
const detail=[
 ['Fallkennung (nur fiktiv)','caseRef'],['Sicherheitsstatus','safety'],['Originalaussage','original'],['Beobachtung','observed'],['Arbeitshypothese','interpretation'],['Quelle','source'],['Zeitbezug','observedAt'],['Gegenhypothese','alternative'],['Möglicher Gegenbeleg','counterEvidence'],['Entscheidende Lücke','criticalGap'],['Details zur Lücke','gapNote'],['Art der Aussage','claimType'],['Nächste Prozessart','nextAction'],['Nächster Schritt','nextWhat'],['Zuständig','nextWho'],['Wiedervorlage','nextWhen'],['Reverse: Belegkette','reverseLink'],['Reverse: Bruchstelle','reverseBreak'],['NSF-Kennung','nsfRef'],['NSF-Status','nsfStatus'],['NSF-Beleg','nsfEvidence']
];
const statusTone=element=>{element.dataset.status=element.textContent.trim()};
const text=(tag,value,cls)=>{const x=document.createElement(tag);if(cls)x.className=cls;x.textContent=value;return x;};
function show(page,force=false){
 if(!pages.includes(page))return;
 if(!force && !started && page!=='intro')return;
 if(!force && data.safety==='yes' && !['a','review'].includes(page))page='a';
 current=page;
 if(page==='intro')byId('desktop-nav').scrollLeft=0;
 pages.forEach(p=>byId('page-'+p).classList.toggle('is-visible',p===page));
 document.querySelectorAll('[data-page]').forEach(b=>{const active=b.dataset.page===page;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'step':'false')});
 byId('footer-nav').hidden=page==='intro';
 const i=pages.indexOf(page);byId('back').disabled=i<=1;byId('next').disabled=i===pages.length-1 || data.safety==='yes' && page==='a';
 byId('next').textContent=i===pages.length-2?'Prüfergebnis →':'Weiter →';
 byId('flow-progress').textContent=page==='depth'?'Optionale Vertiefung':page==='review'?'Ergebnis':`${Math.max(1,i)} / 6`;
 if(page==='review')renderReview();
 if(window.scrollY>130)window.scrollTo({top:0,behavior:'instant'});
 log('Bereich geöffnet: '+page);
}
function populate(){
 document.querySelectorAll('[data-field]').forEach(x=>{let v=x.dataset.field.includes('.')?x.dataset.field.split('.').reduce((o,k)=>o?.[k],data):data[x.dataset.field];if(x.type==='checkbox')x.checked=!!v;else x.value=v??''});
 document.querySelectorAll('[name=safety],[name=claimType],[name=nextAction]').forEach(x=>x.checked=data[x.name]===x.value);
 renderStatus();
}
function statusUpdate(){const result=E.evaluate(data),code=result.gate1.status+'|'+result.gate2.status;
 if(code!==lastGate && started){log('Statusänderung: Gate 1 '+result.gate1.status+', Gate 2 '+result.gate2.status);lastGate=code;}
 const s=byId('g1-inline'),t=byId('g2-inline');s.textContent=result.gate1.status;t.textContent=result.gate2.status;statusTone(s);statusTone(t);
 byId('danger-banner').hidden=!result.emergency;
 if(current==='a')byId('next').disabled=result.emergency;
 if(current==='review')renderReview();
 return result;
}
function renderStatus(){statusUpdate()}
function setData(field,v){latestLoop=null;latestTick=null;const report=byId('a7-loop-report');if(report)report.textContent='Falldaten geändert. A7SEM/Reverse-Loop erneut prüfen.';const seg=field.split('.');if(seg.length===2)data[seg[0]][seg[1]]=v;else data[field]=v;statusUpdate()}
function renderReview(){
 const result=E.evaluate(data);
 for(const n of [1,2]){
 const gate=result['gate'+n],label=byId('gate'+n+'-status');label.textContent=gate.status;statusTone(label);
 byId('gate'+n+'-title').textContent=gate.label;byId('gate'+n+'-explain').textContent=gate.restrictions;
 }
 byId('emergency-review').hidden=!result.emergency;
 const out=byId('review-fields');out.replaceChildren();
 for(const [label,key] of detail){if(!data[key] && key!=='criticalGap')continue;const dl=document.createElement('div');dl.className='review-row';const dt=text('dt',label);const dd=text('dd',String(data[key]||'—'));dl.append(dt,dd);out.append(dl)}
 for(const [title,items] of [['A7SEM',E.A7.map(a=>[a.name,data.a7[a.key]])],['ARGUS-7',E.ARGUS.map((q,i)=>[(i+1)+'. '+q,data.argus['a'+(i+1)]])]]){
 const filled=items.filter(x=>x[1]&&x[1].trim()); if(!filled.length)continue;
 out.append(text('h4',title));for(const [label,value] of filled){const dl=document.createElement('div');dl.className='review-row';dl.append(text('dt',label),text('dd',value));out.append(dl)}
 }
 byId('ruleset-label').textContent='Regelstand: '+result.ruleset+' · keine Anbindung an den kanonischen PIGA-Kernel';
 byId('kernel-state').textContent=B.ready().status;byId('kernel-detail').textContent=B.ready().reason;
 const trace=byId('rule-trace');trace.replaceChildren();
 for(const item of result.trace){const row=document.createElement('div');row.className='trace-item';const head=document.createElement('div');head.className='trace-head';const name=text('b',item.title);const code=text('code',item.ruleId);const status=text('span',item.status,'trace-status');head.append(name,code,status);row.append(head,text('p',item.explanation));trace.append(row)}
 const reasons=byId('review-reasons');reasons.replaceChildren();
 for(const [label,gate] of [['Gate 1',result.gate1],['Gate 2',result.gate2]]){reasons.append(text('h4',label));const ul=document.createElement('ul');ul.className='reasons-list';for(const r of gate.reasons)ul.append(text('li',r));reasons.append(ul)}
 if(result.warnings.length){reasons.append(text('h4','Zusätzliche Warnungen'));const ul=document.createElement('ul');ul.className='reasons-list';for(const x of result.warnings)ul.append(text('li',x));reasons.append(ul)}
 const audit=byId('audit-list');audit.replaceChildren();
 for(const e of events){const row=document.createElement('div');row.className='audit-entry';row.append(text('span',e.event));const t=text('time',new Date(e.at).toLocaleTimeString('de-DE'));t.dateTime=e.at;row.append(t);audit.append(row)}
 if(!events.length)audit.append(text('p','Keine Einträge.'));
}
function start(which){latestLoop=null;latestTick=null;data=which==='demo'?E.demoCase():E.emptyCase();events=[];lastGate='';started=true;log(which==='demo'?'Fiktiven Beispielfall geladen':'Leeren fiktiven Testfall eröffnet');populate();show('a',true)}
function startScenario(s){latestLoop=null;latestTick=null;data=E.norm(s.case);events=[];lastGate='';started=true;log('Fiktives Szenario geladen: '+s.id+' – '+s.title);populate();show('review',true)}
function renderScenarioLab(){const root=byId('scenario-buttons');root.replaceChildren();for(const s of E.scenarios()){
 const b=document.createElement('button');b.type='button';b.className='scenario-button';b.disabled=!byId('consent-demo').checked;
 b.append(text('b',s.title),text('small',s.note));b.addEventListener('click',()=>startScenario(s));root.append(b)
 }}
function runSuite(){const checks=E.runScenarioChecks();const ok=checks.filter(x=>x.pass).length;byId('suite-summary').textContent=`${ok} von ${checks.length} Demo-Szenarien stimmen mit den erwarteten Gate-Statuswerten überein.`;
 const target=byId('suite-results');target.replaceChildren();for(const row of checks){const d=document.createElement('div');d.className='suite-row';d.append(text('span',row.title),text('span',`Gate 1 ${row.actual[0]} · Gate 2 ${row.actual[1]} · ${row.pass?'PASS':'FAIL'}`,row.pass?'suite-ok':'suite-fail'));target.append(d)}
 log('Selbsttest der sechs fiktiven Szenarien: '+ok+'/'+checks.length+' bestanden');
}
function reset(){if(!window.confirm('Fiktiven Fall und unexportierten Sitzungsverlauf lokal verwerfen?'))return;
 latestLoop=null;latestTick=null;data=E.emptyCase();started=false;events=[];lastGate='';populate();show('intro',true)
}
function addDepthFields(){
 const list=[['a7-fields',E.A7,'a7'],['argus-fields',E.ARGUS,'argus']];
 for(const [id,items,scope] of list){
 const root=byId(id);
 items.forEach((item,i)=>{const key=scope==='a7'?item.key:'a'+(i+1),title=scope==='a7'?`${i+1}. ${item.name}`:`${i+1}. ${item}`,question=scope==='a7'?item.question:'Optionales Antwortfeld';
 const div=document.createElement('div');div.className='field-block';const lbl=text('label',title);lbl.htmlFor=`${scope}-${key}`;const small=text('small',question);const area=document.createElement('textarea');area.id=`${scope}-${key}`;area.rows=2;area.dataset.field=`${scope}.${key}`;area.placeholder='Nur fiktiver Fall / UNKNOWN ist möglich';div.append(lbl,area,small);root.append(div)})
 }
}
async function exportJson(){
 if(!started)return;
 log('Lokaler JSON-Export ausgelöst');
 const result=E.evaluate(data);
 const payload={format:'ADOS-GOV-LITE-DEMO',schemaVersion:'0.6',version:E.VERSION,ruleset:E.RULESET,exportedAt:now(),notice:'Nur fiktive Testdaten. Keine klinische Diagnose, externe Freigabe oder digitale Signatur. Export ist unverschlüsselt und nicht authentifiziert.',canonicalKernel:B.ready(),case:data,decision:result,finiteLoopReceipt:latestLoop,continuousCheckpoint:latestTick,sessionEvents:events};
 const sealed=await I.seal(payload);
 byId('export-integrity-status').textContent=sealed.integrity.digest?'SHA-256-Prüfsumme erstellt (keine digitale Signatur).':'Prüfsumme nicht verfügbar: Browser ohne WebCrypto. Keine Integritätsgarantie.';
 const blob=new Blob([JSON.stringify(sealed,null,2)],{type:'application/json;charset=utf-8'});
 const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='ADOS_Governance_Lite_v05_FIKTIV_'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function probeBridge(){
 const state=B.ready(),nonce=B.createNonce();
 const prep=B.prepareRequest(data,{nonce});
 const info={kernel:state.status,code:state.code,localContract:prep.code||prep.status,requestPreview:prep.request?{schema:prep.request.schema,capability:prep.request.capability,scope:prep.request.scope,expiresAfterSeconds:300,payload:prep.request.payload}:null,transmitted:false};
 byId('bridge-readiness').textContent=JSON.stringify(info,null,2);
 log('Offline-Kernel-Vertragsprüfung: '+info.localContract+' · KEINE Übertragung');
}

async function probeLocalBridge(){
 const display=byId('bridge-transport-info');
 if(location.protocol!=='http:' || location.hostname!=='127.0.0.1' || location.port!=='8767'){
   display.textContent='BLOCK · Kein lokaler Demo-Server. Offline-Datei bleibt vollständig getrennt. Starte optional: node server/local-bridge.mjs'; return;
 }
 const nonce=B.createNonce(),prep=B.prepareRequest(data,{nonce});
 if(!prep.request){display.textContent='BLOCK · '+(prep.code||'INVALID_REQUEST')+' (Sicherheitsstatus oder Testmetadaten unzulässig).'; return}
 try {
   const response=await fetch('/api/ados/bridge/admission',{method:'POST',headers:{'Content-Type':'application/json','X-ADOS-Local-Demo':'1'},body:JSON.stringify(prep.request),cache:'no-store',credentials:'omit'});
   if(!response.ok)throw new Error('HTTP '+response.status);
   const packet=await response.json();
   if(typeof packet.signedPayload!=='string'||typeof packet.signature!=='string')throw new Error('Unvollständiges Testpaket');
   const receipt=JSON.parse(packet.signedPayload);
   if(receipt.status!=='BLOCK'||receipt.authoritative!==false||receipt.requestId!==prep.request.requestId||receipt.nonce!==prep.request.nonce||receipt.schema!=='ados-local-bridge-receipt/0.5'||receipt.gate1!=='UNKNOWN'||receipt.gate2!=='BLOCK'||receipt.engineCount!==5||receipt.additionalEngineCreated!==false||receipt.expiresAt<=Date.now()||receipt.issuedAt>Date.now()+30000)throw new Error('Testbescheid inkonsistent oder abgelaufen');
   let signatureLocal='NICHT GEPRÜFT';
   if(window.crypto?.subtle){
      try{const bytes=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
       const key=await crypto.subtle.importKey('spki',bytes(packet.publicKeySpki),{name:'Ed25519'},false,['verify']);
       const good=await crypto.subtle.verify('Ed25519',key,bytes(packet.signature),new TextEncoder().encode(packet.signedPayload));
       signatureLocal=good?'LOKALE TESTSIGNATUR GEPRÜFT':'UNGÜLTIGE TESTSIGNATUR';
      }catch{signatureLocal='TESTSIGNATUR NICHT PRÜFBAR';}
   }
   display.textContent='Kernel BLOCK · Test-Bridge: '+receipt.reason+' · '+signatureLocal+'. Der vom Testdienst mitgelieferte Schlüssel beweist keine kanonische PIGA-Autorität. Keine Falltexte übertragen.';
   log('Lokale Test-Bridge geprüft: '+receipt.reason+'; kanonische Freigabe BLOCK');
 }catch(err){display.textContent='BLOCK · Lokale Verbindung fehlgeschlagen: '+String(err).slice(0,150)}
}
async function checkLocalCoreFile(){
 const input=byId('core-file'),out=byId('core-verdict');
 const file=input.files?.[0];
 out.textContent='BLOCK · Keine Produktionszulassung.';
 if(!file)return;
 if(file.size>24*1024*1024){out.textContent='BLOCK · Datei zu groß (>24 MiB); nicht eingelesen.';return}
 if(!file.name.toLowerCase().endsWith('.zip')){out.textContent='BLOCK · Nur eine ZIP-Bundle-Datei ist hier prüfbar.';return}
 try{
   out.textContent='Prüfe lokale Datei. Keine Übertragung …';
   const result=await C.verifyArrayBuffer(await file.arrayBuffer());
   const prefix=result.identity==='BYTE_HASH_MATCH'?'Identität: SHA-256 stimmt überein.':'Identität nicht bestätigt: '+result.reason+'.';
   out.textContent=prefix+' · PIGA-Autorität: NICHT GEPRÜFT · Gate 1: BLOCK · Gate 2: BLOCK · Nur kontrollierte Evaluation.';
   log('Lokale Core-Datei geprüft: '+result.identity+'; PIGA-Produktionszulassung BLOCK');
 }catch(err){out.textContent='BLOCK · Identitätsprüfung technisch fehlgeschlagen: '+String(err).slice(0,110)}
 finally{input.value=''}
}
function loopInputs(){
 const evidence={};const reverse=[];
 for(const k of L.STEPS){const st=byId('ev-status-'+k).value,ref=byId('ev-ref-'+k).value.trim();evidence[k]={status:st,ref,note:''};}
 for(let i=6;i>=0;i--){const k=L.STEPS[i];reverse.push({claimRef:byId('rv-claim-'+k).value.trim(),sourceRef:byId('rv-source-'+k).value.trim(),checked:byId('rv-checked-'+k).checked,contradicted:byId('rv-contradicted-'+k).checked});}
 return {evidence,reverse};
}
function addLoopFields(){
 if(!L)return;
 const f=byId('a7-loop-evidence'),r=byId('a7-loop-reverse');
 for(let i=0;i<7;i++){
 const k=L.STEPS[i],name=E.A7[i].name;
 const one=document.createElement('div');one.className='loop-stage';
 const heading=text('strong',(i+1)+'. '+name);const status=document.createElement('select');status.id='ev-status-'+k;
 for(const st of ['UNKNOWN','PRESENT','CONTRADICTED','REVOKED']){const op=document.createElement('option');op.value=st;op.textContent=st;status.append(op)}
 status.setAttribute('aria-label',name+' Quellenstatus');
 const ref=document.createElement('input');ref.id='ev-ref-'+k;ref.placeholder='Evidence-ID (synthetisch)';ref.maxLength=120;ref.setAttribute('aria-label',name+' Evidence-ID');
 one.append(heading,status,ref);f.append(one);
 }
 for(let i=6;i>=0;i--){const k=L.STEPS[i],name=E.A7[i].name;const one=document.createElement('div');one.className='loop-stage';one.append(text('strong',(i+1)+'. '+name+' · Reverse'));
 for(const [prefix,placeholder] of [['claim','Behauptungs-ID'],['source','Beleg-ID identisch zu A7SEM']]){const inp=document.createElement('input');inp.id='rv-'+prefix+'-'+k;inp.placeholder=placeholder;inp.maxLength=120;inp.setAttribute('aria-label',name+' '+placeholder);one.append(inp)}
 for(const [name2,label] of [['checked','Zuordnung geprüft'],['contradicted','Widerspruch']]){const lbl=document.createElement('label');lbl.className='loop-check';const chk=document.createElement('input');chk.id='rv-'+name2+'-'+k;chk.type='checkbox';lbl.append(chk,text('span',label));one.append(lbl)}r.append(one);
 }
}
function runLoop(){if(!started)return;latestLoop=L.finite(data,loopInputs(),7);
 const s=latestLoop;byId('a7-loop-report').textContent=JSON.stringify({mode:'FINITE',status:s.loop.state,reason:s.loop.reason,iterations:s.loop.iterations,findings:s.findings,steps:s.loop.steps,canonicalAuthority:s.authority.status},null,2);
 log('Finite A7SEM/Reverse: '+s.loop.state+' · Kernel BLOCK');}
function tickLoop(){if(!started)return;const prev=latestTick,control={now:Date.now(),expiresAt:Date.now()+5*60*1000,humanReview:byId('loop-human-reviewed').checked,revoked:byId('loop-revoked').checked,evidenceEpoch:byId('loop-epoch').value};
 latestTick=L.continuousTick(data,loopInputs(),prev,control);
 byId('a7-loop-report').textContent=JSON.stringify(latestTick,null,2);
 log('Re-Entry-Checkpoint: '+latestTick.reason+' · keine automatische Wiederholung');}
function boot(){
 addDepthFields();addLoopFields();renderScenarioLab();
 document.querySelectorAll('#a7-loop-evidence input, #a7-loop-evidence select, #a7-loop-reverse input').forEach(el=>el.addEventListener('change',()=>{latestLoop=null;latestTick=null;byId('a7-loop-report').textContent='Belegbindung geändert. Finite Loop und Re-Entry müssen neu geprüft werden.';}));
 byId("run-a7-loop").addEventListener("click",runLoop);byId("tick-a7-loop").addEventListener("click",tickLoop);
 byId('consent-demo').addEventListener('change',e=>{byId('start-demo').disabled=!e.target.checked;byId('start-empty').disabled=!e.target.checked;byId('run-suite').disabled=!e.target.checked;renderScenarioLab()});
 byId('run-suite').addEventListener('click',runSuite);
 byId('reset-demo').addEventListener('click',reset);
 byId('start-demo').addEventListener('click',()=>start('demo'));
 byId('start-empty').addEventListener('click',()=>start('empty'));
 document.querySelectorAll('[data-page]').forEach(btn=>btn.addEventListener('click',()=>show(btn.dataset.page)));
 byId('back').addEventListener('click',()=>show(pages[Math.max(1,pages.indexOf(current)-1)]));
 byId('next').addEventListener('click',()=>show(pages[Math.min(pages.length-1,pages.indexOf(current)+1)]));
 document.querySelectorAll('[data-field]').forEach(x=>{
 const fn=()=>setData(x.dataset.field,x.type==='checkbox'?x.checked:x.value);
 x.addEventListener(x.type==='checkbox'||x.tagName==='SELECT'?'change':'input',fn);
 });
 document.querySelectorAll('input[name=safety],input[name=claimType],input[name=nextAction]').forEach(x=>x.addEventListener('change',()=>{
 if(x.checked){setData(x.name,x.value);if(x.name==='safety'&&x.value==='yes')show('a',true)}
 }));
 byId('print-top').addEventListener('click',()=>{if(started){renderReview();window.print()}});
 byId('print-report').addEventListener('click',()=>{renderReview();window.print()});
 byId('download-json').addEventListener('click',exportJson);
 byId('prepare-bridge').addEventListener('click',probeBridge);
 byId('probe-local').addEventListener('click',probeLocalBridge);
 byId('core-file').addEventListener('change',checkLocalCoreFile);
 populate();show('intro',true);
 // On HTTPS/localhost only: cache the static app shell. Never request remote resources.
 if('serviceWorker' in navigator&&['https:','http:'].includes(location.protocol))navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
