/* SHA-256 detects changes in an exported JSON file, not who authored/signed it. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.ADOSIntegrity=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function sortJSON(x){if(Array.isArray(x))return x.map(sortJSON);if(x&&typeof x==='object'){const o={};for(const k of Object.keys(x).sort())o[k]=sortJSON(x[k]);return o;}return x;}
function canonical(x){return JSON.stringify(sortJSON(x));}
async function sha256(text){if(!globalThis.crypto?.subtle)return null;const b=new TextEncoder().encode(text);const hash=await globalThis.crypto.subtle.digest('SHA-256',b);return Array.from(new Uint8Array(hash),v=>v.toString(16).padStart(2,'0')).join('');}
async function seal(payload){const canonicalText=canonical(payload),digest=await sha256(canonicalText);return {payload,integrity:{algorithm:digest?'SHA-256':'UNAVAILABLE',digest:digest||null,kind:'untrusted_local_checksum',scope:'payload_only',warning:'Nur lokale Änderungserkennung, kein digital signierter oder revisionssicherer Nachweis.'}};}
async function verify(sealed){if(!sealed?.integrity?.digest||!sealed?.payload)return {ok:false,reason:'NO_CHECKSUM'};const h=await sha256(canonical(sealed.payload));return {ok:h!==null&&h===sealed.integrity.digest,reason:h===null?'NO_WEBCRYPTO':h===sealed.integrity.digest?'HASH_MATCH':'HASH_MISMATCH'};}
return {canonical,sha256,seal,verify};
});
