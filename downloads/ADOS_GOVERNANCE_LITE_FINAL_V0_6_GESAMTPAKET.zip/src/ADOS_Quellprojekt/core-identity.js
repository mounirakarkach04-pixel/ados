/* ADOS v0.5: exact-byte identity check for the separately published K2.1.1 RC bundle.
   A byte match proves file identity ONLY; it cannot establish authorization, current
   revocation status, production readiness or clinical validation. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.ADOSCoreIdentity=factory()})(typeof globalThis!== 'undefined'?globalThis:this,function(){
'use strict';
const CORE={version:'PIGA-K2.1.1-RC-v0.7',name:'PIGA_K2.1.1_RC_20260723_INTEGRATED_PROGRAM_CONTROL_v0.7.zip',sha256:'a84001ad8cf3e5aef9123b33e641f6012b4ffc3b67814630121ebbd5bdc63605',scopeSha256:'e3206c695a0c35b0e796a87bba5484fbb66267b83e16aa586f99cc50091e5c9f',evidence:'PIGA K2.1.1 External Product Dossier v1.3.2, Drive, 23.07.2026',release:'CONTROLLED_EXTERNAL_REVIEW_ONLY',production:'DELAY'};
function verdict(digest){
 if(typeof digest!=='string'||!/^[a-f0-9]{64}$/i.test(digest))return {identity:'UNKNOWN',reason:'HASH_MISSING_OR_INVALID',canonicalAdmission:'BLOCK',authoritative:false};
 const ok=digest.toLowerCase()===CORE.sha256;
 return {identity:ok?'BYTE_HASH_MATCH':'HASH_MISMATCH',reason:ok?'Exact-byte SHA-256 equals accepted RC bundle reference. Does not prove legitimate authority.':'Supplied file differs from recorded accepted RC bundle.',canonicalAdmission:'BLOCK',authoritative:false,productionAllowed:false,scopeVerified:false,rootOfAuthorityVerified:false,revocationChecked:false,clinicalAllowed:false};
}
async function verifyArrayBuffer(buffer){
 if(!(buffer instanceof ArrayBuffer))return {...verdict(null),computedSha256:null};
 if(typeof crypto==='undefined'||!crypto.subtle)return {identity:'UNKNOWN',reason:'WEBCRYPTO_UNAVAILABLE',canonicalAdmission:'BLOCK',authoritative:false};
 const digest=await crypto.subtle.digest('SHA-256',buffer);
 const hex=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
 return {...verdict(hex),computedSha256:hex};
}
return {CORE,verdict,verifyArrayBuffer};
});
