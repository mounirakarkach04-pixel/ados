ADOS — VOLLSTÄNDIGES OFFLINE-WEBPAKET (FORSCHUNGSDEMO)
© 2026 Mounir Akarkach. Keine klinische Diagnostik oder Therapie.

INSTALLATION
1. ZIP VOLLSTÄNDIG in einen Ordner entpacken. Dateien zusammenlassen.
2. index.html in einem lokalen HTML-fähigen Browser öffnen.
3. Buchvorstellung, Evidence Studio, Governance Lite und Rechtstexte sind im Paket.
4. Die Buchvorstellung ist KEIN vollständiges Buch-Manuskript oder Amazon-E-Book.
5. Die psychologischen Lehrfälle sind FIKTIV. Niemals reale Klienten- oder Patientendaten eingeben.
6. Gate 1 ist nur eine dokumentarische Lerndemo; klinische Handlungen: Gate 2 BLOCK.
7. Von der App zur BuchVORSTELLUNGSSEITE mit den internen Links zurückkehren.
8. Browser- und Android-Dateianbieter können lokale Verknüpfungen via content:// einschränken.
   In diesem Fall einzelne Apps öffnen oder die verifizierte Online-Buchseite nutzen:
   https://pigapocket.com/ados/  (benötigt Internet).
9. Externe Links (Amazon, franz. LA PREUVE LAB, PIGA) brauchen Internet.
10. Keine Kosten oder Cloud-Anmeldung für die lokale Nutzung; Exporte lokal und unverschlüsselt.

Paketinhalt: index.html, studio.html, governance-lite.html, offline-downloads.html,
datenschutz.html, nutzungsbedingungen.html, Cover, Symbol, PWA-Dateien, Excel-Matrix.

A7SEM Reverse: endliche Link- und Archivprüfung beim Erstellen. Keine klinische Freigabe.
