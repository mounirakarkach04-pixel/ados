LA PREUVE LAB — SUITE FRANÇAISE TOTALEMENT HORS LIGNE
Auteur : Mounir Akarkach
Version : 2026-10-24 / lien offline corrigé

1. Décompressez ENTIÈREMENT l’archive ZIP. Gardez tous les fichiers dans le MÊME dossier.
2. Ouvrez index.html du dossier décompressé, puis naviguez : Livre, LAB, QM, Studio, Étude et informations légales.
3. Les liens internes, y compris sur Android dans un navigateur prenant en charge les fichiers locaux, restent locaux. Certaines restrictions de navigateur ou d’accès au système de fichiers peuvent s’appliquer.
4. Un fichier HTML téléchargé seul ne comprend PAS les autres pages. Pour toutes les pages sans Internet, utilisez ce ZIP.
5. Les liens vers Amazon, OMS, ADOS et PIGA Pocket sont EXTERNES et nécessitent Internet.
6. Cas inventés uniquement. Pas de patients, pas de diagnostics ni de prise en charge réelle. Gate 2 clinique: BLOCK.
7. Les événements temporaires doivent être exportés en CSV/JSON avant fermeture. Aucune signature réglementaire.
8. Aucun coût, abonnement, CDN ni compte n’est nécessaire pour l’utilisation locale.

© 2026 Mounir Akarkach · PIGA / A7SEM Reverse
